# DKHCBC UMS — Developer Onboarding Guide

Welcome to the DKHCBC University Management System codebase!

## Architecture at a Glance

The system is a **monorepo** with two main applications:

```
eth-ums/
├── backend/   — Python FastAPI REST API
└── frontend/  — Next.js 14 TypeScript SPA
```

They communicate over HTTP REST. The backend exposes `/api/v1/*` endpoints;
the frontend calls them via the Axios client in `frontend/src/lib/api.ts`.

---

## Backend: Key Concepts

### 1. Service Routers

Each functional domain has its own router in `backend/services/<name>/router.py`.
All routers are mounted in `backend/main.py` with a prefix like `/api/v1/students`.

```
services/
├── auth/       → JWT login, token refresh, RBAC dependency
├── student/    → Student CRUD + enrollment history
├── faculty/    → Faculty profiles + section assignments
├── academic/   → Courses, programs, grades (CA/Mid/Final)
├── registrar/  → Enrollment approval + PDF transcript generation
├── finance/    → Fees (ETB), payments, scholarships
├── library/    → Books, loans, overdue fines
├── notification/ → User + broadcast notifications
├── analytics/  → KPI dashboards + trend data
└── admin/      → User management + audit log viewer
```

### 2. Authentication & RBAC

Every protected endpoint uses a FastAPI `Depends`:

```python
# Require any authenticated user
current_user: Annotated[User, Depends(get_current_user)]

# Require specific roles
_: Annotated[User, Depends(require_roles(UserRole.ADMIN, UserRole.REGISTRAR))]
```

Both are defined in `services/auth/router.py`.

### 3. Database Models

All SQLAlchemy ORM models live in `shared/models/orm_models.py`. Key design decisions:
- Every entity with a user-facing name has `_en` and `_am` (Amharic) fields.
- Financial amounts are stored as `Numeric(10, 2)` in **ETB**.
- Ethiopian Calendar dates are stored as strings in `_ec` suffix fields.
- `TimestampMixin` provides `created_at`/`updated_at` on most tables.

### 4. Adding a New Endpoint

```python
# 1. Add schema (Pydantic model) at top of router
class WidgetCreate(BaseModel):
    name_en: str
    name_am: Optional[str] = None

# 2. Add route
@router.post("/widgets", status_code=201)
async def create_widget(
    body: WidgetCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(require_roles(UserRole.ADMIN))],
):
    widget = Widget(**body.model_dump())
    db.add(widget)
    await db.commit()
    await db.refresh(widget)
    return widget
```

### 5. Adding a New Database Table

```bash
# 1. Add model to shared/models/orm_models.py
# 2. Generate migration
alembic revision --autogenerate -m "add_widgets_table"
# 3. Review generated migration in alembic/versions/
# 4. Apply
alembic upgrade head
```

### 6. Ethiopian Grading Logic

All grading calculations are in `shared/utils/gpa_calculator.py`:
- `score_to_grade(total)` → converts 0–100 score to `(grade_symbol, grade_points)`
- `compute_cgpa(courses)` → weighted average across credit hours
- `gpa_standing(cgpa)` → returns English + Amharic standing labels

---

## Frontend: Key Concepts

### 1. App Router Structure

```
src/app/
├── layout.tsx              — Root: fonts, AuthProvider, Toaster
├── page.tsx                — Redirects to /dashboard
├── login/page.tsx          — Login form with demo credentials
└── dashboard/
    ├── layout.tsx          — Sidebar + topbar + auth guard
    └── <module>/page.tsx   — One page per UMS module
```

### 2. API Layer

All API calls go through `src/lib/api.ts`. Never call `fetch()` directly.

```typescript
// Good
import { studentsApi } from "@/lib/api";
const students = await studentsApi.list({ q: "abebe" });

// Never
const res = await fetch("/api/v1/students");
```

The Axios instance automatically:
- Attaches the JWT from cookies
- Redirects to `/login` on 401

### 3. Auth Context

```typescript
import { useAuth } from "@/hooks/useAuth";

const { user, login, logout, isRole } = useAuth();

// Check role
if (isRole("admin", "registrar")) {
  // show admin UI
}
```

### 4. Adding a New Page

1. Create `src/app/dashboard/<name>/page.tsx`
2. Add a nav entry in `src/app/dashboard/layout.tsx` (NAV array)
3. Add API methods to `src/lib/api.ts` if needed
4. Add TypeScript types to `src/types/index.ts`

---

## Code Style

### Python
- Type hints everywhere
- `async`/`await` throughout (no blocking I/O)
- Pydantic v2 models for all request/response bodies
- `structlog` for structured logging (not `print`)

### TypeScript
- Strict mode enabled
- No `any` types — use proper interfaces from `src/types/`
- Server state with `useState` + `useEffect` (no Redux needed at this scale)
- `sonner` for user feedback (not `alert()`)

---

## Running Tests Locally

```bash
cd backend

# Quick run
pytest tests/ -v

# With coverage
pytest tests/ --cov=. --cov-report=term-missing

# Single test
pytest tests/test_auth.py::test_login_success -v
```

---

## Useful Commands

```bash
# Watch backend logs
docker compose logs -f backend

# Django-style shell (async)
cd backend && python -c "
import asyncio
from shared.config.database import AsyncSessionLocal
from shared.models.orm_models import Student
from sqlalchemy import select

async def main():
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Student).limit(5))
        for s in result.scalars():
            print(s.student_id)

asyncio.run(main())
"

# Reset database (DEV ONLY)
docker compose down -v && docker compose up -d db redis
docker compose exec backend alembic upgrade head
docker compose exec backend python seed.py
```
