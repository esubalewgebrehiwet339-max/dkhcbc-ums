# DKHCBC UMS — Database Schema Documentation

## Overview

The database uses **PostgreSQL 16** with an async connection via `asyncpg`.
All migrations are managed by **Alembic** (see `alembic/versions/`).

---

## Table Reference

### `universities`
Stores institution-level data. Multi-tenant capable.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| code | VARCHAR(20) UNIQUE | e.g. "DKHCBC" |
| name_en | VARCHAR(200) | English name |
| name_am | VARCHAR(200) | Amharic name |
| address | TEXT | |
| region | VARCHAR(100) | Ethiopian region |
| woreda | VARCHAR(100) | Sub-district |
| kebele | VARCHAR(100) | Village/ward |
| phone | VARCHAR(30) | |
| email | VARCHAR(100) | |
| is_active | BOOLEAN | Default: true |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

---

### `users`
All system users across roles. One record per person.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| university_id | INTEGER FK → universities | |
| email | VARCHAR(150) UNIQUE | Login identifier |
| password_hash | VARCHAR(255) | bcrypt hash |
| role | ENUM | admin, registrar, finance, department_head, professor, librarian, student |
| first_name_en | VARCHAR(100) | |
| last_name_en | VARCHAR(100) | |
| first_name_am | VARCHAR(100) | Amharic first name |
| last_name_am | VARCHAR(100) | Amharic last name |
| phone | VARCHAR(30) | |
| is_active | BOOLEAN | |
| last_login | TIMESTAMPTZ | |

**Indexes:** `ix_users_email`

---

### `departments`
Academic departments within a university.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| university_id | INTEGER FK | |
| code | VARCHAR(20) | e.g. "THEO" |
| name_en | VARCHAR(200) | |
| name_am | VARCHAR(200) | |
| head_id | INTEGER FK → users | Department head |
| is_active | BOOLEAN | |

**Unique:** `(university_id, code)`

---

### `programs`
Degree/diploma programs offered by a department.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| department_id | INTEGER FK | |
| code | VARCHAR(30) UNIQUE | e.g. "DIP-THEO" |
| name_en | VARCHAR(200) | |
| name_am | VARCHAR(200) | |
| degree_type | VARCHAR(50) | Diploma, Bachelor, Masters |
| total_credits | INTEGER | |
| duration_years | INTEGER | |

---

### `academic_years`
Ethiopian and Gregorian year labels.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| label_ec | VARCHAR(20) UNIQUE | "2016/17 E.C." |
| label_gc | VARCHAR(20) | "2023/24 G.C." |
| start_date | DATE | |
| end_date | DATE | |
| is_current | BOOLEAN | Only one should be true |

---

### `students`
Student-specific profile data (extends `users`).

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| user_id | INTEGER FK → users UNIQUE | |
| student_id | VARCHAR(30) UNIQUE | "DKHCBC/001/17" |
| date_of_birth | DATE | Gregorian |
| dob_ec | VARCHAR(30) | Ethiopian Calendar DOB |
| gender | VARCHAR(10) | M / F |
| region | VARCHAR(100) | Ethiopian region |
| woreda | VARCHAR(100) | |
| kebele | VARCHAR(100) | |
| sponsor_type | ENUM | government, private, ngo, self |
| emergency_name | VARCHAR(200) | |
| emergency_phone | VARCHAR(30) | |

**Indexes:** `ix_students_student_id`

---

### `faculty`
Faculty/instructor-specific profile.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| user_id | INTEGER FK → users UNIQUE | |
| department_id | INTEGER FK | |
| employee_id | VARCHAR(30) UNIQUE | "FAC-2020-001" |
| title | VARCHAR(50) | "Rev.", "Dr.", "Prof." |
| specialization | VARCHAR(200) | |
| qualification | VARCHAR(200) | Highest degree |
| hired_date | DATE | |

---

### `courses`
Course catalog entries.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| department_id | INTEGER FK | |
| code | VARCHAR(20) UNIQUE | "THEO101" |
| name_en | VARCHAR(300) | |
| name_am | VARCHAR(300) | |
| section_group | VARCHAR(100) | "Biblical Studies", "Ministry" |
| credit_hours | INTEGER | Default: 3 |

---

### `course_sections`
A specific offering of a course in a semester.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| course_id | INTEGER FK | |
| instructor_id | INTEGER FK → faculty | |
| academic_year_id | INTEGER FK | |
| semester | ENUM | semester_i, semester_ii, summer |
| section_code | VARCHAR(10) | "A", "B" |
| max_students | INTEGER | Seat capacity |
| room | VARCHAR(50) | Classroom |
| schedule | VARCHAR(200) | "Mon/Wed 08:00–10:00" |

---

### `enrollments`
Student ↔ section registration.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| student_id | INTEGER FK | |
| section_id | INTEGER FK | |
| program_id | INTEGER FK | |
| status | ENUM | active, withdrawn, graduated, suspended, probation |
| enrolled_at | TIMESTAMPTZ | |
| approved_by | INTEGER FK → users | Registrar who approved |
| approved_at | TIMESTAMPTZ | |

**Unique:** `(student_id, section_id)`

---

### `grades`
Grade record per student per section.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| student_id | INTEGER FK | |
| section_id | INTEGER FK | |
| ca_score | NUMERIC(5,2) | Continuous Assessment (30%) |
| mid_score | NUMERIC(5,2) | Mid-term (30%) |
| final_score | NUMERIC(5,2) | Final Exam (40%) |
| total_score | NUMERIC(5,2) | Computed: CA×0.3 + Mid×0.3 + Final×0.4 |
| grade_symbol | ENUM | A+, A, A−, B+, B, B−, C+, C, F, I, W |
| grade_points | NUMERIC(4,2) | 0.0–4.0 |
| is_finalized | BOOLEAN | Once finalized, shown on transcript |
| submitted_by | INTEGER FK → users | Professor who submitted |

**Unique:** `(student_id, section_id)`

---

### `fee_structures`
Fee amounts defined per program per academic year.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| program_id | INTEGER FK | |
| academic_year_id | INTEGER FK | |
| tuition_etb | NUMERIC(10,2) | Main tuition in ETB |
| registration_etb | NUMERIC(10,2) | Registration fee |
| other_fees_etb | NUMERIC(10,2) | Miscellaneous |

---

### `fee_records`
Per-student billing record for an academic year.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| student_id | INTEGER FK | |
| fee_structure_id | INTEGER FK | |
| total_due_etb | NUMERIC(10,2) | |
| paid_etb | NUMERIC(10,2) | Running total paid |
| status | ENUM | paid, partial, overdue, waived |
| due_date | DATE | |

---

### `payments`
Individual payment transactions.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| fee_record_id | INTEGER FK | |
| amount_etb | NUMERIC(10,2) | |
| payment_date | DATE | |
| receipt_no | VARCHAR(50) | Physical receipt number |
| method | VARCHAR(50) | cash, bank_transfer, mobile_money |
| recorded_by | INTEGER FK → users | Finance officer |

---

### `scholarships`
Scholarship and financial aid awards.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| student_id | INTEGER FK | |
| name_en | VARCHAR(200) | Scholarship name |
| name_am | VARCHAR(200) | |
| amount_etb | NUMERIC(10,2) | |
| academic_year_id | INTEGER FK | |
| is_active | BOOLEAN | |

---

### `books`
Library book catalog.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| isbn | VARCHAR(20) UNIQUE | |
| title_en | VARCHAR(400) | |
| title_am | VARCHAR(400) | Amharic title |
| author | VARCHAR(300) | |
| publisher | VARCHAR(200) | |
| year | INTEGER | |
| category | VARCHAR(100) | |
| total_copies | INTEGER | Physical copies owned |
| available | INTEGER | Copies not on loan |

---

### `library_loans`
Book borrowing records.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| book_id | INTEGER FK | |
| student_id | INTEGER FK | |
| issued_at | TIMESTAMPTZ | |
| due_date | DATE | Default: issued + 14 days |
| returned_at | TIMESTAMPTZ | NULL if still borrowed |
| status | ENUM | borrowed, returned, overdue, lost |
| fine_etb | NUMERIC(8,2) | ETB 2/day overdue |
| fine_paid | BOOLEAN | |

---

### `notifications`
System notifications. `user_id = NULL` = broadcast to all.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| user_id | INTEGER FK (nullable) | NULL = broadcast |
| title | VARCHAR(300) | |
| title_am | VARCHAR(300) | |
| message | TEXT | |
| message_am | TEXT | |
| type | VARCHAR(50) | info, warning, success, error |
| is_read | BOOLEAN | |
| sent_by | INTEGER FK → users | |

---

### `audit_logs`
Immutable log of all mutating API actions.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| user_id | INTEGER FK (nullable) | NULL if unauthenticated |
| action | VARCHAR(100) | HTTP method: POST, PATCH, DELETE |
| resource | VARCHAR(100) | URL path segment |
| resource_id | VARCHAR(50) | ID from URL |
| details | TEXT | Optional description |
| ip_address | VARCHAR(45) | IPv4 or IPv6 |
| user_agent | VARCHAR(500) | Browser/client string |
| created_at | TIMESTAMPTZ | |

**Indexes:** `ix_audit_logs_user_id`, `ix_audit_logs_created_at`

---

## Entity-Relationship Summary

```
universities ──< departments ──< programs
                              ──< courses ──< course_sections
universities ──< users ──< students ──< enrollments >── course_sections
                       ──< faculty  ──< course_sections (instructor)

students ──< enrollments
         ──< grades
         ──< fee_records ──< payments
         ──< scholarships
         ──< library_loans >── books

course_sections ──< enrollments
                ──< grades

academic_years ──< course_sections
               ──< fee_structures
               ──< scholarships
```
