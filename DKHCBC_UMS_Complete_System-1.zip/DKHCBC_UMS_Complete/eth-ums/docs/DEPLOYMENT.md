# DKHCBC UMS — Deployment Guide

## Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| Docker | ≥ 24 | Container runtime |
| Docker Compose | ≥ 2.20 | Local orchestration |
| Python | 3.11+ | Backend runtime |
| Node.js | 20+ | Frontend build |
| kubectl | ≥ 1.28 | Kubernetes deployment |
| PostgreSQL | 16 | Database (via Docker or managed) |
| Redis | 7 | Cache and rate limiting |

---

## Step 1 — Clone & Configure

```bash
git clone https://github.com/your-org/dkhcbc-ums.git
cd dkhcbc-ums/eth-ums
cp .env.example .env
```

Edit `.env`:

```bash
# REQUIRED — generate a strong JWT secret
JWT_SECRET_KEY=$(python -c "import secrets; print(secrets.token_hex(64))")

# Update SMTP settings for email notifications
SMTP_HOST=smtp.gmail.com
SMTP_USER=noreply@dkhcbc.edu.et
SMTP_PASSWORD=your_app_password
```

---

## Step 2 — Start with Docker Compose

```bash
# Build and start all services
docker compose up -d --build

# Verify all containers are healthy
docker compose ps

# Expected output:
# dkhcbc_db        running (healthy)
# dkhcbc_redis     running (healthy)
# dkhcbc_backend   running (healthy)
# dkhcbc_frontend  running
# dkhcbc_nginx     running
# dkhcbc_prometheus running
# dkhcbc_grafana   running
```

---

## Step 3 — Initialize Database

```bash
# Run Alembic migrations (creates all 18 tables)
docker compose exec backend alembic upgrade head

# Seed initial data
docker compose exec backend python seed.py
```

---

## Step 4 — Verify Deployment

```bash
# Health check
curl http://localhost/health
# {"status":"ok","version":"2.0.0","service":"DKHCBC UMS"}

# API docs
open http://localhost/api/docs

# Frontend
open http://localhost
```

---

## Production Checklist

Before going live, complete all of the following:

- [ ] Set `ENVIRONMENT=production` and `DEBUG=false` in `.env`
- [ ] Generate a strong 64-character `JWT_SECRET_KEY`
- [ ] Change all default passwords in the database (`python seed.py` sets demo passwords)
- [ ] Configure real SMTP credentials for email notifications
- [ ] Set `ALLOWED_ORIGINS` to your actual frontend domain(s)
- [ ] Enable HTTPS in Nginx (`infra/nginx/nginx.conf` — uncomment the redirect block)
- [ ] Place TLS certificates in `infra/nginx/ssl/`
- [ ] Set up automated PostgreSQL backups
- [ ] Configure Grafana dashboards with alert rules
- [ ] Review and restrict `/metrics` endpoint access in Nginx

---

## Kubernetes Production Deployment

### 1. Build and push images

```bash
# Backend
docker build -t your-registry/dkhcbc-backend:v2.0.0 backend/
docker push your-registry/dkhcbc-backend:v2.0.0

# Frontend
docker build -t your-registry/dkhcbc-frontend:v2.0.0 frontend/ \
  --build-arg NEXT_PUBLIC_API_URL=https://ums.dkhcbc.edu.et/api/v1
docker push your-registry/dkhcbc-frontend:v2.0.0
```

### 2. Update secrets

Edit `infra/k8s/00-namespace-config.yaml` with real values for:
- `DATABASE_URL`
- `REDIS_URL`  
- `JWT_SECRET_KEY`
- `POSTGRES_PASSWORD`

### 3. Deploy

```bash
kubectl apply -f infra/k8s/
kubectl rollout status deployment/dkhcbc-backend -n dkhcbc-ums
kubectl rollout status deployment/dkhcbc-frontend -n dkhcbc-ums
```

### 4. Run migrations

```bash
kubectl exec -n dkhcbc-ums deployment/dkhcbc-backend -- alembic upgrade head
kubectl exec -n dkhcbc-ums deployment/dkhcbc-backend -- python seed.py
```

---

## Updating the Application

### Rolling update (zero downtime)

```bash
# Build new image
docker build -t your-registry/dkhcbc-backend:v2.1.0 backend/

# Update Kubernetes deployment
kubectl set image deployment/dkhcbc-backend \
  backend=your-registry/dkhcbc-backend:v2.1.0 \
  -n dkhcbc-ums

# Run any new migrations
kubectl exec -n dkhcbc-ums deployment/dkhcbc-backend -- alembic upgrade head
```

### Rollback

```bash
kubectl rollout undo deployment/dkhcbc-backend -n dkhcbc-ums
```

---

## Backup & Restore

### PostgreSQL backup

```bash
# Create backup
docker compose exec db pg_dump -U dkhcbc dkhcbc_ums > backup_$(date +%Y%m%d).sql

# Restore
docker compose exec -T db psql -U dkhcbc dkhcbc_ums < backup_20250314.sql
```

### Transcript file backup

```bash
# Transcripts are stored in the Docker volume
docker run --rm -v dkhcbc_transcript_outputs:/data \
  -v $(pwd):/backup alpine \
  tar czf /backup/transcripts_$(date +%Y%m%d).tar.gz /data
```

---

## Troubleshooting

### Backend won't start
```bash
docker compose logs backend
# Check DATABASE_URL and REDIS_URL are correct
```

### Migrations fail
```bash
docker compose exec backend alembic current
docker compose exec backend alembic history
# If needed, reset: docker compose exec backend alembic downgrade base
```

### Cannot generate transcripts (PDF)
```bash
# Verify Ethiopic fonts are installed
docker compose exec backend fc-list | grep -i "ethiopic\|freefont\|noto"
```

### Rate limit errors (429)
Increase `RATE_LIMIT_REQUESTS` in `.env` or restart Redis to clear the counters:
```bash
docker compose restart redis
```
