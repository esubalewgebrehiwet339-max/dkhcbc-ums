/**
 * DKHCBC UMS — Axios API Client
 * Centralised HTTP client with JWT injection and error handling.
 */

import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";
import Cookies from "js-cookie";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

export const api = axios.create({
  baseURL: BASE_URL,
  timeout: 30_000,
  headers: { "Content-Type": "application/json" },
});

// ── Request interceptor — attach JWT ─────────────────────────────────────────
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = Cookies.get("access_token");
  if (token && config.headers) {
    config.headers["Authorization"] = `Bearer ${token}`;
  }
  return config;
});

// ── Response interceptor — handle 401 ────────────────────────────────────────
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    if (error.response?.status === 401) {
      Cookies.remove("access_token");
      Cookies.remove("refresh_token");
      if (typeof window !== "undefined") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authApi = {
  login: (email: string, password: string) =>
    api.post("/auth/login", { email, password }),
  me: () => api.get("/auth/me"),
  refresh: (refresh_token: string) =>
    api.post("/auth/refresh", { refresh_token }),
  changePassword: (current_password: string, new_password: string) =>
    api.post("/auth/change-password", { current_password, new_password }),
};

// ── Students ──────────────────────────────────────────────────────────────────
export const studentsApi = {
  list: (params?: { q?: string; skip?: number; limit?: number }) =>
    api.get("/students", { params }),
  get: (studentId: string) => api.get(`/students/${studentId}`),
  create: (data: Record<string, unknown>) => api.post("/students", data),
  update: (studentId: string, data: Record<string, unknown>) =>
    api.patch(`/students/${studentId}`, data),
  enrollments: (studentId: string) =>
    api.get(`/students/${studentId}/enrollments`),
};

// ── Faculty ───────────────────────────────────────────────────────────────────
export const facultyApi = {
  list: (params?: { department_id?: number; q?: string }) =>
    api.get("/faculty", { params }),
  get: (employeeId: string) => api.get(`/faculty/${employeeId}`),
  create: (data: Record<string, unknown>) => api.post("/faculty", data),
  update: (employeeId: string, data: Record<string, unknown>) =>
    api.patch(`/faculty/${employeeId}`, data),
  sections: (employeeId: string) =>
    api.get(`/faculty/${employeeId}/sections`),
};

// ── Academic ──────────────────────────────────────────────────────────────────
export const academicApi = {
  programs: () => api.get("/academic/programs"),
  courses: (params?: { department_id?: number; section_group?: string }) =>
    api.get("/academic/courses", { params }),
  sections: (params?: { academic_year_id?: number }) =>
    api.get("/academic/sections", { params }),
  submitGrade: (data: Record<string, unknown>) =>
    api.post("/academic/grades", data),
  finalizeGrade: (gradeId: number) =>
    api.patch(`/academic/grades/${gradeId}/finalize`),
  studentGpa: (studentId: number) =>
    api.get(`/academic/students/${studentId}/gpa`),
};

// ── Registrar ─────────────────────────────────────────────────────────────────
export const registrarApi = {
  students: (params?: { q?: string; status?: string }) =>
    api.get("/registrar/students", { params }),
  transcriptData: (studentId: string) =>
    api.get(`/registrar/students/${studentId}/transcript-data`),
  generateTranscript: (data: {
    student_id: string;
    purpose?: string;
    transcript_no?: string;
  }) => api.post("/registrar/transcripts/generate", data),
  enrollmentQueue: () => api.get("/registrar/enrollment-queue"),
  approveEnrollment: (enrollmentId: number) =>
    api.patch(`/registrar/enrollment-queue/${enrollmentId}/approve`),
};

// ── Finance ───────────────────────────────────────────────────────────────────
export const financeApi = {
  feeStructures: () => api.get("/finance/fee-structures"),
  records: (params?: { status?: string }) =>
    api.get("/finance/records", { params }),
  studentRecords: (studentId: string) =>
    api.get(`/finance/records/student/${studentId}`),
  recordPayment: (data: Record<string, unknown>) =>
    api.post("/finance/payments", data),
  scholarships: () => api.get("/finance/scholarships"),
  createScholarship: (data: Record<string, unknown>) =>
    api.post("/finance/scholarships", data),
  summary: () => api.get("/finance/summary"),
};

// ── Library ───────────────────────────────────────────────────────────────────
export const libraryApi = {
  books: (params?: { q?: string; category?: string }) =>
    api.get("/library/books", { params }),
  issueBook: (data: Record<string, unknown>) =>
    api.post("/library/loans", data),
  returnBook: (loanId: number) =>
    api.patch(`/library/loans/${loanId}/return`),
  overdueLoans: () => api.get("/library/loans/overdue"),
};

// ── Notifications ─────────────────────────────────────────────────────────────
export const notificationsApi = {
  list: () => api.get("/notifications"),
  markRead: (notificationId: number) =>
    api.patch(`/notifications/${notificationId}/read`),
  markAllRead: () => api.patch("/notifications/mark-all-read"),
  send: (data: Record<string, unknown>) => api.post("/notifications", data),
};

// ── Analytics ─────────────────────────────────────────────────────────────────
export const analyticsApi = {
  dashboard: () => api.get("/analytics/dashboard"),
  enrollmentTrends: () => api.get("/analytics/enrollment-trends"),
  gpaDistribution: () => api.get("/analytics/gpa-distribution"),
  financeMonthly: () => api.get("/analytics/finance-monthly"),
};

// ── Admin ─────────────────────────────────────────────────────────────────────
export const adminApi = {
  users: () => api.get("/admin/users"),
  createUser: (data: Record<string, unknown>) =>
    api.post("/admin/users", data),
  auditLogs: (params?: { skip?: number; limit?: number }) =>
    api.get("/admin/audit-logs", { params }),
};
