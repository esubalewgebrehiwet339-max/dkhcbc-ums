"use client";

import { useEffect, useState } from "react";
import { adminApi } from "@/lib/api";
import type { AuditLog } from "@/types";

const ACTION_STYLE: Record<string, string> = {
  POST:   "text-green-400 bg-green-500/10",
  PATCH:  "text-yellow-400 bg-yellow-500/10",
  PUT:    "text-blue-400 bg-blue-500/10",
  DELETE: "text-red-400 bg-red-500/10",
};

export default function AuditPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminApi.auditLogs({ limit: 100 })
      .then((r) => setLogs(r.data))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Audit Logs</h1>
        <p className="text-sm text-[#7B8DB8] mt-0.5">
          All mutating API actions across all services ({logs.length} entries)
        </p>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1E2640]">
                {["Timestamp","User ID","Method","Resource","Resource ID","IP Address"].map((h) => (
                  <th key={h} className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase tracking-wider font-semibold whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-12 text-[#3E4C70]">Loading…</td></tr>
              ) : logs.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-[#3E4C70]">No audit logs</td></tr>
              ) : logs.map((log, i) => (
                <tr key={log.id}
                  className={`border-b border-[#1E2640] hover:bg-[#161C2E] transition-colors ${i%2===1?"bg-[#161C2E]/30":""}`}>
                  <td className="px-4 py-2.5 font-mono text-xs text-[#3E4C70] whitespace-nowrap">
                    {new Date(log.created_at).toLocaleString()}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-brand-500">
                    {log.user_id ?? "—"}
                  </td>
                  <td className="px-4 py-2.5">
                    <span className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${ACTION_STYLE[log.action] ?? "text-[#7B8DB8]"}`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-[#EEF2FF] text-xs">{log.resource}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-[#7B8DB8]">
                    {log.resource_id ?? "—"}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-[#3E4C70]">
                    {log.ip_address ?? "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
