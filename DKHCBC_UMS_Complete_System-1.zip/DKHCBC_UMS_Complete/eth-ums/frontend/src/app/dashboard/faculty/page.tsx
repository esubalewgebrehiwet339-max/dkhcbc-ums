"use client";

import { useEffect, useState } from "react";
import { facultyApi } from "@/lib/api";
import type { Faculty } from "@/types";

export default function FacultyPage() {
  const [faculty, setFaculty] = useState<Faculty[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    facultyApi.list().then((r) => setFaculty(r.data)).finally(() => setLoading(false));
  }, []);

  const filtered = faculty.filter(
    (f: Faculty & { user?: { first_name_en?: string; last_name_en?: string } }) =>
      !search ||
      `${f.user?.first_name_en} ${f.user?.last_name_en}`.toLowerCase().includes(search.toLowerCase()) ||
      f.employee_id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Faculty & Staff</h1>
          <p className="text-sm text-[#7B8DB8] mt-0.5">{faculty.length} faculty members</p>
        </div>
        <button className="btn-primary">+ Add Faculty</button>
      </div>

      <input className="input" placeholder="Search by name or employee ID…"
        value={search} onChange={(e) => setSearch(e.target.value)} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-3 text-center py-20 text-[#3E4C70]">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="col-span-3 text-center py-20 text-[#3E4C70]">No faculty found</div>
        ) : filtered.map((f: Faculty & { user?: { first_name_en?: string; last_name_en?: string; first_name_am?: string; last_name_am?: string } }) => (
          <div key={f.id} className="card p-5">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-sm font-bold flex-shrink-0">
                {f.user?.first_name_en?.charAt(0) ?? "?"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-[#EEF2FF] truncate">
                  {f.title} {f.user?.first_name_en} {f.user?.last_name_en}
                </p>
                {f.user?.first_name_am && (
                  <p className="text-xs text-[#7B8DB8] amharic">{f.user.first_name_am} {f.user.last_name_am}</p>
                )}
              </div>
              <span className={f.is_active ? "badge-green" : "badge-red"}>
                {f.is_active ? "Active" : "Inactive"}
              </span>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-[#3E4C70]">Employee ID</span>
                <span className="font-mono text-brand-500">{f.employee_id}</span>
              </div>
              {f.specialization && (
                <div className="flex justify-between">
                  <span className="text-[#3E4C70]">Specialization</span>
                  <span className="text-[#7B8DB8] text-right max-w-[60%] truncate">{f.specialization}</span>
                </div>
              )}
              {f.qualification && (
                <div className="flex justify-between">
                  <span className="text-[#3E4C70]">Qualification</span>
                  <span className="text-[#7B8DB8]">{f.qualification}</span>
                </div>
              )}
              {f.hired_date && (
                <div className="flex justify-between">
                  <span className="text-[#3E4C70]">Hired</span>
                  <span className="text-[#7B8DB8] font-mono">{f.hired_date}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
