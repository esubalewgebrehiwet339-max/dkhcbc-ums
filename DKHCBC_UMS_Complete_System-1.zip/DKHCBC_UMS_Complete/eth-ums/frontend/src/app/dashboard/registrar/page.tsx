"use client";

import { useEffect, useState } from "react";
import { registrarApi } from "@/lib/api";
import { toast } from "sonner";

export default function RegistrarPage() {
  const [queue, setQueue] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState<string | null>(null);

  useEffect(() => {
    registrarApi.enrollmentQueue()
      .then((r) => setQueue(r.data))
      .catch(() => toast.error("Failed to load enrollment queue"))
      .finally(() => setLoading(false));
  }, []);

  const approve = async (id: number) => {
    try {
      await registrarApi.approveEnrollment(id);
      setQueue((q) => q.filter((e) => (e as Record<string,unknown>).id !== id));
      toast.success("Enrollment approved");
    } catch {
      toast.error("Failed to approve enrollment");
    }
  };

  const generateTranscript = async (studentId: string) => {
    setGenerating(studentId);
    try {
      const res = await registrarApi.generateTranscript({ student_id: studentId });
      toast.success(`Transcript generated: ${res.data.transcript_no}`);
    } catch {
      toast.error("Failed to generate transcript");
    } finally {
      setGenerating(null);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Registrar Office</h1>
        <p className="text-sm text-[#7B8DB8] mt-0.5">Enrollment approvals, transcripts & academic calendar</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Enrollment Queue */}
        <div className="card">
          <div className="px-5 py-3 border-b border-[#1E2640] flex justify-between items-center">
            <span className="text-sm font-semibold text-[#EEF2FF]">Enrollment Queue</span>
            <span className="badge-gold">{queue.length} pending</span>
          </div>
          <div className="divide-y divide-[#1E2640]">
            {loading ? (
              <div className="text-center py-10 text-[#3E4C70]">Loading…</div>
            ) : queue.length === 0 ? (
              <div className="text-center py-10 text-[#3E4C70]">No pending enrollments</div>
            ) : queue.slice(0, 8).map((e) => {
              const en = e as Record<string, unknown>;
              return (
                <div key={en.id as number} className="flex items-center justify-between px-5 py-3 hover:bg-[#161C2E]">
                  <div>
                    <p className="text-sm text-[#EEF2FF] font-medium">Enrollment #{en.id as number}</p>
                    <p className="text-xs text-[#7B8DB8] font-mono">
                      Student #{en.student_id as number} · Section #{en.section_id as number}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => approve(en.id as number)}
                      className="text-xs px-3 py-1.5 rounded-lg bg-green-500/10 text-green-400 border border-green-500/20 hover:bg-green-500/20 transition-colors">
                      ✓ Approve
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Academic Calendar */}
        <div className="card">
          <div className="px-5 py-3 border-b border-[#1E2640]">
            <span className="text-sm font-semibold text-[#EEF2FF]">Academic Calendar 2016/17 E.C.</span>
          </div>
          <div className="p-4 grid grid-cols-1 gap-3">
            {[
              ["Semester I Start",  "Meskerem 5, 2016",  "Sep 15, 2023",  "completed"],
              ["Semester I End",    "Tahsas 30, 2016",   "Jan 8, 2024",   "completed"],
              ["Semester II Start", "Yekatit 1, 2016",   "Feb 9, 2024",   "completed"],
              ["Semester II End",   "Sene 25, 2016",     "Jul 1, 2024",   "upcoming"],
              ["Graduation Ceremony","Hamle 15, 2016",   "Jul 21, 2024",  "upcoming"],
              ["Summer Session",    "Hamle–Nehase",      "Jul–Sep 2024",  "upcoming"],
            ].map(([evt, ec, gc, status]) => (
              <div key={evt} className="flex items-center gap-3 bg-[#161C2E] rounded-lg px-3 py-2.5">
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${status === "completed" ? "bg-[#22C97A]" : "bg-[#F0A830]"}`} />
                <div className="flex-1">
                  <p className="text-xs font-medium text-[#EEF2FF]">{evt}</p>
                  <p className="text-[10px] text-brand-500">{ec}</p>
                </div>
                <span className="text-[10px] text-[#3E4C70]">{gc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Transcript Generator */}
      <div className="card">
        <div className="px-5 py-3 border-b border-[#1E2640]">
          <span className="text-sm font-semibold text-[#EEF2FF]">Transcript Generator</span>
          <p className="text-xs text-[#7B8DB8] mt-0.5">Generate official PDF transcripts in English & Amharic</p>
        </div>
        <div className="p-4 flex flex-col gap-3">
          <div className="flex gap-3">
            <input className="input" placeholder="Enter Student ID (e.g. DKHCBC/001/17)" id="tStId" />
            <button
              onClick={() => {
                const id = (document.getElementById("tStId") as HTMLInputElement).value;
                if (id) generateTranscript(id);
              }}
              disabled={!!generating}
              className="btn-primary whitespace-nowrap flex items-center gap-2 disabled:opacity-60">
              {generating ? (
                <><span className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin" />Generating…</>
              ) : "📄 Generate Transcript"}
            </button>
          </div>
          <p className="text-xs text-[#3E4C70]">
            Transcripts are generated as PDF files with bilingual content (English + Amharic / አማርኛ).
            The file will be available via the download endpoint after generation.
          </p>
        </div>
      </div>
    </div>
  );
}
