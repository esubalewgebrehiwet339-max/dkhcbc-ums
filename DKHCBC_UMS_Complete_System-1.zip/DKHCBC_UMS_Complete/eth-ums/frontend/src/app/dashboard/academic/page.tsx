"use client";

import { useEffect, useState } from "react";
import { academicApi } from "@/lib/api";
import type { Course, Program } from "@/types";

const GRADING_SCALE = [
  ["A+", "90–100", "4.0"], ["A", "85–89", "4.0"], ["A-", "80–84", "3.7"],
  ["B+", "75–79", "3.3"], ["B", "70–74", "3.0"], ["B-", "65–69", "2.7"],
  ["C+", "60–64", "2.3"], ["C", "55–59", "2.0"],
  ["F",  "< 55",  "0.0"],  ["I", "Incomplete", "—"], ["W", "Withdrawn", "—"],
];

export default function AcademicPage() {
  const [courses, setCourses]   = useState<Course[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [tab, setTab]           = useState<"courses" | "programs" | "scale">("courses");
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    Promise.all([academicApi.courses(), academicApi.programs()])
      .then(([c, p]) => { setCourses(c.data); setPrograms(p.data); })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Academic Management</h1>
        <p className="text-sm text-[#7B8DB8] mt-0.5">Courses, programs & Ethiopian grading scale</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-[#111520] border border-[#1E2640] rounded-lg p-1 w-fit">
        {(["courses","programs","scale"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-md text-xs font-medium capitalize transition-colors
              ${tab === t ? "bg-brand-500 text-white" : "text-[#7B8DB8] hover:text-[#EEF2FF]"}`}>
            {t === "scale" ? "Grading Scale" : t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {/* Courses Tab */}
      {tab === "courses" && (
        <div className="card overflow-hidden">
          <div className="px-5 py-3 border-b border-[#1E2640] text-sm font-semibold text-[#EEF2FF]">
            Course Catalog ({courses.length} courses)
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1E2640]">
                  {["Code","Course Name (EN)","Amharic Title","Group","Credits","Active"].map((h) => (
                    <th key={h} className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase tracking-wider font-semibold">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={6} className="text-center py-10 text-[#3E4C70]">Loading…</td></tr>
                ) : courses.map((c, i) => (
                  <tr key={c.id} className={`border-b border-[#1E2640] hover:bg-[#161C2E] ${i%2===1?"bg-[#161C2E]/30":""}`}>
                    <td className="px-4 py-2.5 font-mono text-xs text-brand-500 font-semibold">{c.code}</td>
                    <td className="px-4 py-2.5 text-[#EEF2FF]">{c.name_en}</td>
                    <td className="px-4 py-2.5 text-[#7B8DB8] amharic text-xs">{c.name_am ?? "—"}</td>
                    <td className="px-4 py-2.5 text-xs text-purple-400">{c.section_group ?? "—"}</td>
                    <td className="px-4 py-2.5 text-center text-[#7B8DB8]">{c.credit_hours}</td>
                    <td className="px-4 py-2.5">
                      <span className={c.is_active ? "badge-green" : "badge-red"}>
                        {c.is_active ? "Active" : "Inactive"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Programs Tab */}
      {tab === "programs" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {programs.map((p) => (
            <div key={p.id} className="card p-5">
              <div className="flex justify-between items-start mb-3">
                <span className="font-mono text-xs text-brand-500 font-semibold">{p.code}</span>
                <span className={p.is_active ? "badge-green" : "badge-red"}>{p.degree_type}</span>
              </div>
              <h3 className="font-semibold text-[#EEF2FF] mb-1">{p.name_en}</h3>
              {p.name_am && <p className="text-xs text-[#7B8DB8] amharic mb-3">{p.name_am}</p>}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-[#161C2E] rounded p-2">
                  <p className="text-[#3E4C70] mb-0.5">Duration</p>
                  <p className="text-[#EEF2FF] font-semibold">{p.duration_years} Years</p>
                </div>
                <div className="bg-[#161C2E] rounded p-2">
                  <p className="text-[#3E4C70] mb-0.5">Total Credits</p>
                  <p className="text-[#EEF2FF] font-semibold">{p.total_credits}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Grading Scale Tab */}
      {tab === "scale" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="card overflow-hidden">
            <div className="px-5 py-3 border-b border-[#1E2640] text-sm font-semibold text-[#EEF2FF]">
              Ethiopian Grading Scale
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1E2640]">
                  <th className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase">Grade</th>
                  <th className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase">Score Range</th>
                  <th className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase">Grade Points</th>
                </tr>
              </thead>
              <tbody>
                {GRADING_SCALE.map(([grade, range, points], i) => (
                  <tr key={grade} className={`border-b border-[#1E2640] ${i%2===1?"bg-[#161C2E]/30":""}`}>
                    <td className="px-4 py-2.5 font-semibold font-mono text-brand-500">{grade}</td>
                    <td className="px-4 py-2.5 text-[#7B8DB8]">{range}</td>
                    <td className="px-4 py-2.5 font-mono text-[#EEF2FF]">{points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-[#EEF2FF] mb-4">Grading Formula</h3>
            <div className="space-y-3">
              {[
                ["Continuous Assessment (CA)", "30%", "#22C97A"],
                ["Mid-term Examination", "30%", "#3B6EF5"],
                ["Final Examination", "40%", "#F0A830"],
              ].map(([label, pct, color]) => (
                <div key={label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#7B8DB8]">{label}</span>
                    <span className="font-mono font-semibold" style={{ color }}>{pct}</span>
                  </div>
                  <div className="h-1.5 bg-[#1E2640] rounded-full">
                    <div className="h-full rounded-full" style={{ width: pct, background: color }} />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-5 p-3 bg-[#161C2E] rounded-lg text-xs text-[#7B8DB8]">
              <p className="font-semibold text-[#EEF2FF] mb-1">Academic Standings</p>
              {[
                ["≥ 3.75", "Summa Cum Laude"],
                ["≥ 3.50", "Magna Cum Laude"],
                ["≥ 3.25", "Cum Laude"],
                ["≥ 2.00", "Satisfactory"],
                ["< 2.00", "Academic Probation"],
              ].map(([gpa, standing]) => (
                <div key={standing} className="flex justify-between py-0.5">
                  <span className="font-mono text-brand-500">{gpa}</span>
                  <span>{standing}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
