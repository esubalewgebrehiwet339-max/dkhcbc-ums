"use client";

import { useEffect, useState } from "react";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer,
} from "recharts";
import { analyticsApi } from "@/lib/api";
import type { DashboardData, EnrollmentTrend, GpaDistribution } from "@/types";

const fmt = (n: number) => n?.toLocaleString("en-ET") ?? "0";
const fmtETB = (n: number) => `ETB ${fmt(Math.round(n))}`;

const COLORS = {
  accent: "#3B6EF5", green: "#22C97A", gold: "#F0A830",
  red: "#F04A4A", purple: "#9B6BFF",
};

const GPA_COLORS: Record<string, string> = {
  "A+": "#22C97A", "A": "#22C97A", "A-": "#22C97A",
  "B+": "#3B6EF5", "B": "#3B6EF5", "B-": "#3B6EF5",
  "C+": "#F0A830", "C": "#F0A830",
  "F": "#F04A4A", "I": "#F04A4A", "W": "#F04A4A",
};

function StatCard({ icon, label, value, sub, color, badge }: {
  icon: string; label: string; value: string;
  sub?: string; color: string; badge?: string;
}) {
  return (
    <div className="card p-5 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background: color }} />
      <div className="flex justify-between items-start">
        <div>
          <span className="text-2xl">{icon}</span>
          <p className="text-xs text-[#7B8DB8] uppercase tracking-wider mt-1 mb-2">{label}</p>
          <p className="text-3xl font-bold font-mono text-[#EEF2FF]">{value}</p>
          {sub && <p className="text-xs text-[#3E4C70] mt-1">{sub}</p>}
        </div>
        {badge && (
          <span className="text-xs px-2 py-1 rounded-full font-semibold border"
            style={{ color, background: `${color}20`, borderColor: `${color}40` }}>
            {badge}
          </span>
        )}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [trends, setTrends] = useState<EnrollmentTrend[]>([]);
  const [gpaDist, setGpaDist] = useState<GpaDistribution[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      analyticsApi.dashboard(),
      analyticsApi.enrollmentTrends(),
      analyticsApi.gpaDistribution(),
    ]).then(([d, t, g]) => {
      setData(d.data);
      setTrends(t.data);
      setGpaDist(g.data);
    }).catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500/30 border-t-brand-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Academic Overview</h1>
        <p className="text-sm text-[#7B8DB8] mt-1">
          2016/17 E.C. · Debre Kidan Holy Cross Bible College
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard icon="👤" label="Total Students"
          value={fmt(data?.students.total ?? 0)}
          sub={`${fmt(data?.students.active ?? 0)} active`}
          color={COLORS.accent} badge="+12%" />
        <StatCard icon="🎓" label="Avg. CGPA"
          value={(data?.academic.average_gpa ?? 0).toFixed(2)}
          sub={`${fmt(data?.academic.graded_courses ?? 0)} graded`}
          color={COLORS.green} />
        <StatCard icon="💰" label="Collection Rate"
          value={`${(data?.finance.collection_rate ?? 0).toFixed(1)}%`}
          sub={fmtETB(data?.finance.total_paid_etb ?? 0)}
          color={COLORS.gold} badge="ETB" />
        <StatCard icon="📚" label="Active Loans"
          value={fmt(data?.library.active_loans ?? 0)}
          sub="Library checkouts"
          color={COLORS.purple} />
        <StatCard icon="💸" label="Outstanding"
          value={fmtETB(data?.finance.outstanding_etb ?? 0)}
          sub="Pending payments"
          color={COLORS.red} badge="⚠" />
        <StatCard icon="📋" label="Graded Courses"
          value={fmt(data?.academic.graded_courses ?? 0)}
          sub="Finalized grades"
          color={COLORS.accent} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Enrollment Trend */}
        <div className="card p-5">
          <h2 className="text-sm font-semibold text-[#EEF2FF] mb-4">Enrollment Trends (12 Months)</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={trends} barSize={18}>
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#3E4C70" }}
                tickFormatter={(v: string) => v.slice(-2)} />
              <YAxis tick={{ fontSize: 10, fill: "#3E4C70" }} />
              <Tooltip
                contentStyle={{ background: "#111520", border: "1px solid #1E2640", borderRadius: 8, fontSize: 12 }}
                labelStyle={{ color: "#7B8DB8" }}
              />
              <Bar dataKey="count" fill={COLORS.accent} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* GPA Distribution */}
        <div className="card p-5">
          <h2 className="text-sm font-semibold text-[#EEF2FF] mb-4">Grade Distribution</h2>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={120} height={120}>
              <PieChart>
                <Pie data={gpaDist} dataKey="count" cx="50%" cy="50%"
                  innerRadius={30} outerRadius={55}>
                  {gpaDist.map((entry) => (
                    <Cell key={entry.grade} fill={GPA_COLORS[entry.grade] ?? "#3E4C70"} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-1">
              {[
                ["A Range", COLORS.green, gpaDist.filter(g => g.grade.startsWith("A")).reduce((s,x) => s+x.count, 0)],
                ["B Range", COLORS.accent, gpaDist.filter(g => g.grade.startsWith("B")).reduce((s,x) => s+x.count, 0)],
                ["C Range", COLORS.gold,   gpaDist.filter(g => g.grade.startsWith("C")).reduce((s,x) => s+x.count, 0)],
                ["Below C", COLORS.red,    gpaDist.filter(g => ["F","I","W"].includes(g.grade)).reduce((s,x) => s+x.count, 0)],
              ].map(([label, color, count]) => (
                <div key={label as string} className="flex items-center gap-2 text-xs">
                  <div className="w-2 h-2 rounded-sm flex-shrink-0" style={{ background: color as string }} />
                  <span className="text-[#7B8DB8] flex-1">{label as string}</span>
                  <span className="text-[#EEF2FF] font-semibold font-mono">{count as number}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Finance progress */}
      <div className="card p-5">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-sm font-semibold text-[#EEF2FF]">Financial Collections</h2>
          <span className="text-xs text-[#7B8DB8]">{fmtETB(data?.finance.total_due_etb ?? 0)} total due</span>
        </div>
        <div className="grid grid-cols-3 gap-6">
          {[
            ["Collected", data?.finance.total_paid_etb, COLORS.green],
            ["Outstanding", data?.finance.outstanding_etb, COLORS.red],
            ["Collection Rate", null, COLORS.gold],
          ].map(([label, amount, color]) => (
            <div key={label as string}>
              <p className="text-xs text-[#7B8DB8] mb-1">{label as string}</p>
              <p className="text-xl font-bold font-mono" style={{ color: color as string }}>
                {amount !== null && amount !== undefined
                  ? fmtETB(amount as number)
                  : `${(data?.finance.collection_rate ?? 0).toFixed(1)}%`}
              </p>
              <div className="h-1 bg-[#1E2640] rounded mt-2">
                <div className="h-full rounded transition-all duration-700"
                  style={{
                    background: color as string,
                    width: `${amount !== null && amount !== undefined
                      ? ((amount as number) / (data?.finance.total_due_etb || 1)) * 100
                      : (data?.finance.collection_rate ?? 0)}%`
                  }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
