"use client";

import { useEffect, useState } from "react";
import { notificationsApi } from "@/lib/api";
import type { Notification } from "@/types";
import { toast } from "sonner";

const TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string }> = {
  academic:     { icon: "🎓", color: "#3B6EF5", bg: "#3B6EF520" },
  finance:      { icon: "💰", color: "#F04A4A", bg: "#F04A4A20" },
  library:      { icon: "📚", color: "#9B6BFF", bg: "#9B6BFF20" },
  registration: { icon: "📋", color: "#F0A830", bg: "#F0A83020" },
  info:         { icon: "ℹ️",  color: "#7B8DB8", bg: "#7B8DB820" },
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    notificationsApi.list()
      .then((r) => setNotifications(r.data))
      .catch(() => toast.error("Failed to load notifications"))
      .finally(() => setLoading(false));
  }, []);

  const markRead = async (id: number) => {
    try {
      await notificationsApi.markRead(id);
      setNotifications((n) => n.map((x) => x.id === id ? { ...x, is_read: true } : x));
    } catch { /* silent */ }
  };

  const markAllRead = async () => {
    try {
      await notificationsApi.markAllRead();
      setNotifications((n) => n.map((x) => ({ ...x, is_read: true })));
      toast.success("All notifications marked as read");
    } catch {
      toast.error("Failed to update notifications");
    }
  };

  const unread = notifications.filter((n) => !n.is_read).length;

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Notifications</h1>
          <p className="text-sm text-[#7B8DB8] mt-0.5">{unread} unread</p>
        </div>
        {unread > 0 && (
          <button onClick={markAllRead} className="btn-ghost text-xs">
            Mark all read
          </button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-20 text-[#3E4C70]">Loading…</div>
      ) : notifications.length === 0 ? (
        <div className="text-center py-20 text-[#3E4C70]">No notifications</div>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => {
            const cfg = TYPE_CONFIG[n.type] ?? TYPE_CONFIG.info;
            return (
              <div
                key={n.id}
                onClick={() => !n.is_read && markRead(n.id)}
                className={`card p-4 cursor-pointer hover:bg-[#161C2E] transition-all duration-150
                  ${!n.is_read ? "border-[#3B6EF540]" : "opacity-70"}`}
              >
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center text-lg flex-shrink-0"
                    style={{ background: cfg.bg }}>
                    {cfg.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start gap-2">
                      <p className={`text-sm font-semibold ${n.is_read ? "text-[#7B8DB8]" : "text-[#EEF2FF]"}`}>
                        {n.title}
                      </p>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {!n.is_read && (
                          <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: cfg.color }} />
                        )}
                      </div>
                    </div>
                    {n.title_am && (
                      <p className="text-xs text-[#3E4C70] amharic">{n.title_am}</p>
                    )}
                    <p className="text-xs text-[#7B8DB8] mt-1">{n.message}</p>
                    {n.message_am && (
                      <p className="text-xs text-[#3E4C70] amharic mt-0.5">{n.message_am}</p>
                    )}
                    <p className="text-[10px] text-[#3E4C70] mt-2">
                      {new Date(n.created_at).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
