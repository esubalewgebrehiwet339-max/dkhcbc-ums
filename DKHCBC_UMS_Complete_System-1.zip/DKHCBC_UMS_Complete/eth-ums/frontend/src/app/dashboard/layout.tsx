"use client";

import { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";

const NAV = [
  { href: "/dashboard",              icon: "◈", label: "Dashboard",     roles: [] },
  { href: "/dashboard/students",     icon: "⊙", label: "Students",      roles: ["admin","registrar","finance"] },
  { href: "/dashboard/faculty",      icon: "◉", label: "Faculty",       roles: ["admin","registrar"] },
  { href: "/dashboard/academic",     icon: "⊛", label: "Academic",      roles: [] },
  { href: "/dashboard/registrar",    icon: "⊞", label: "Registrar",     roles: ["admin","registrar"] },
  { href: "/dashboard/finance",      icon: "⊟", label: "Finance",       roles: ["admin","finance"] },
  { href: "/dashboard/library",      icon: "⊠", label: "Library",       roles: [] },
  { href: "/dashboard/notifications",icon: "⊡", label: "Notifications", roles: [] },
  { href: "/dashboard/audit",        icon: "⊢", label: "Audit Logs",    roles: ["admin"] },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, loading, logout, isRole } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.push("/login");
  }, [loading, user, router]);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-brand-500/30 border-t-brand-500 rounded-full animate-spin" />
      </div>
    );
  }

  const visibleNav = NAV.filter(
    (n) => n.roles.length === 0 || n.roles.some((r) => isRole(r))
  );

  return (
    <div className="flex h-screen bg-[#0A0D14] overflow-hidden">
      {/* ── Sidebar ─────────────────────────────────────────────────────── */}
      <aside
        className={`${collapsed ? "w-14" : "w-56"} bg-[#111520] border-r border-[#1E2640]
                    flex flex-col flex-shrink-0 transition-all duration-200`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-[#1E2640]">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-sm flex-shrink-0">
            ✝
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <p className="text-xs font-bold font-serif text-[#EEF2FF] leading-tight">DKHCBC</p>
              <p className="text-[10px] text-[#3E4C70] leading-tight">University System</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 overflow-y-auto">
          {visibleNav.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-2.5 mx-2 rounded-lg mb-0.5
                            border-l-2 transition-all duration-150 text-sm
                            ${active
                              ? "bg-brand-500/10 border-brand-500 text-brand-500 font-semibold"
                              : "border-transparent text-[#7B8DB8] hover:bg-[#161C2E] hover:text-[#EEF2FF]"
                            }`}
              >
                <span className="text-base flex-shrink-0 font-mono">{item.icon}</span>
                {!collapsed && <span className="truncate">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* User info */}
        <div className="border-t border-[#1E2640] p-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-xs font-bold flex-shrink-0">
              {user.full_name_en.charAt(0)}
            </div>
            {!collapsed && (
              <div className="flex-1 overflow-hidden">
                <p className="text-xs font-medium text-[#EEF2FF] truncate">{user.full_name_en}</p>
                <p className="text-[10px] text-[#3E4C70] capitalize">{user.role}</p>
              </div>
            )}
            {!collapsed && (
              <button
                onClick={logout}
                className="text-[#3E4C70] hover:text-[#F04A4A] text-xs transition-colors"
                title="Logout"
              >
                ⏻
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* ── Main ────────────────────────────────────────────────────────── */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Top bar */}
        <header className="h-12 bg-[#111520] border-b border-[#1E2640] flex items-center px-5 gap-4 flex-shrink-0">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-[#7B8DB8] hover:text-[#EEF2FF] transition-colors text-lg"
          >
            ☰
          </button>
          <div className="flex-1" />
          <span className="text-xs font-mono text-[#3E4C70]">2016/17 E.C.</span>
          <div className="w-px h-5 bg-[#1E2640]" />
          <div className="badge-green text-[10px]">● Online</div>
          <div className="w-px h-5 bg-[#1E2640]" />
          <span className="text-xs text-[#3E4C70]">v2.0.0</span>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
