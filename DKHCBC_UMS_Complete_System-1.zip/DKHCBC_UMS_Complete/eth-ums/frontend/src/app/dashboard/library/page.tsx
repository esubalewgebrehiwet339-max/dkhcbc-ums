"use client";

import { useEffect, useState } from "react";
import { libraryApi } from "@/lib/api";
import type { Book } from "@/types";

export default function LibraryPage() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    libraryApi.books().then((r) => setBooks(r.data)).finally(() => setLoading(false));
  }, []);

  const filtered = books.filter(
    (b) =>
      b.title_en.toLowerCase().includes(search.toLowerCase()) ||
      b.author.toLowerCase().includes(search.toLowerCase()) ||
      (b.category ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const totalBooks     = books.reduce((s, b) => s + b.total_copies, 0);
  const totalAvailable = books.reduce((s, b) => s + b.available, 0);
  const totalOnLoan    = totalBooks - totalAvailable;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Library Management</h1>
        <p className="text-sm text-[#7B8DB8] mt-0.5">Book catalog, loans, returns & fines</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          ["Total Titles",  books.length,     "#3B6EF5"],
          ["Total Copies",  totalBooks,       "#9B6BFF"],
          ["Available",     totalAvailable,   "#22C97A"],
          ["On Loan",       totalOnLoan,      "#F0A830"],
        ].map(([label, value, color]) => (
          <div key={label as string} className="card p-4">
            <p className="text-xs text-[#3E4C70] uppercase tracking-wide mb-1">{label as string}</p>
            <p className="text-2xl font-bold font-mono" style={{ color: color as string }}>{value as number}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <input className="input" placeholder="Search by title, author or category…"
        value={search} onChange={(e) => setSearch(e.target.value)} />

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-3 border-b border-[#1E2640] text-sm font-semibold text-[#EEF2FF]">
          Book Catalog ({filtered.length} titles)
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1E2640]">
                {["ISBN","Title","Amharic Title","Author","Category","Total","Available","On Loan"].map((h) => (
                  <th key={h} className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="text-center py-10 text-[#3E4C70]">Loading…</td></tr>
              ) : filtered.map((b, i) => {
                const onLoan = b.total_copies - b.available;
                return (
                  <tr key={b.id} className={`border-b border-[#1E2640] hover:bg-[#161C2E] ${i%2===1?"bg-[#161C2E]/30":""}`}>
                    <td className="px-4 py-2.5 font-mono text-xs text-[#3E4C70]">{b.isbn ?? "—"}</td>
                    <td className="px-4 py-2.5 text-[#EEF2FF] max-w-xs">{b.title_en}</td>
                    <td className="px-4 py-2.5 text-[#7B8DB8] amharic text-xs">{b.title_am ?? "—"}</td>
                    <td className="px-4 py-2.5 text-[#7B8DB8]">{b.author}</td>
                    <td className="px-4 py-2.5 text-xs text-purple-400">{b.category ?? "—"}</td>
                    <td className="px-4 py-2.5 text-center text-[#7B8DB8] font-mono">{b.total_copies}</td>
                    <td className="px-4 py-2.5 text-center font-mono font-semibold"
                      style={{ color: b.available > 0 ? "#22C97A" : "#F04A4A" }}>
                      {b.available}
                    </td>
                    <td className="px-4 py-2.5 text-center font-mono"
                      style={{ color: onLoan > 0 ? "#F0A830" : "#3E4C70" }}>
                      {onLoan}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
