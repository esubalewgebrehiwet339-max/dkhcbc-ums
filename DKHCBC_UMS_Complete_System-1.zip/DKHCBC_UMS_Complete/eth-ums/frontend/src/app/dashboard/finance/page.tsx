"use client";

import { useEffect, useState } from "react";
import { financeApi } from "@/lib/api";

const fmt = (n: number) => n?.toLocaleString("en-ET") ?? "0";
const fmtETB = (n: number) => `ETB ${fmt(Math.round(n))}`;

const STATUS_BADGE: Record<string, string> = {
  paid: "badge-green", partial: "badge-gold",
  overdue: "badge-red", waived: "badge-purple",
};

export default function FinancePage() {
  const [summary, setSummary] = useState<Record<string, number> | null>(null);
  const [records, setRecords] = useState<Record<string, unknown>[]>([]);
  const [scholarships, setScholarships] = useState<Record<string, unknown>[]>([]);
  const [tab, setTab] = useState<"records" | "scholarships">("records");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      financeApi.summary(),
      financeApi.records(),
      financeApi.scholarships(),
    ]).then(([s, r, sc]) => {
      setSummary(s.data);
      setRecords(r.data);
      setScholarships(sc.data);
    }).finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Finance & Billing</h1>
        <p className="text-sm text-[#7B8DB8] mt-0.5">Tuition fees, payments in ETB, scholarships</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          ["Total Due",       summary?.total_due_etb,       "#EEF2FF", "💰"],
          ["Collected",       summary?.total_paid_etb,      "#22C97A", "✅"],
          ["Outstanding",     summary?.outstanding_etb,     "#F04A4A", "⚠️"],
          ["Collection Rate", null,                         "#F0A830", "📊"],
        ].map(([label, amount, color, icon]) => (
          <div key={label as string} className="card p-4">
            <p className="text-xs text-[#3E4C70] uppercase tracking-wide mb-1">{icon as string} {label as string}</p>
            <p className="text-xl font-bold font-mono" style={{ color: color as string }}>
              {amount !== null && amount !== undefined
                ? fmtETB(amount as number)
                : `${(summary?.collection_rate_pct ?? 0).toFixed(1)}%`}
            </p>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      {summary && (
        <div className="card p-4">
          <div className="flex justify-between text-xs text-[#7B8DB8] mb-2">
            <span>Collection Progress</span>
            <span className="font-mono text-[#22C97A]">{summary.collection_rate_pct?.toFixed(1)}%</span>
          </div>
          <div className="h-2 bg-[#1E2640] rounded-full">
            <div className="h-full bg-gradient-to-r from-brand-500 to-[#22C97A] rounded-full transition-all duration-700"
              style={{ width: `${Math.min(summary.collection_rate_pct ?? 0, 100)}%` }} />
          </div>
          <div className="flex justify-between text-xs mt-1">
            <span className="text-[#22C97A]">{fmtETB(summary.total_paid_etb)} collected</span>
            <span className="text-[#F04A4A]">{fmtETB(summary.outstanding_etb)} outstanding</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 bg-[#111520] border border-[#1E2640] rounded-lg p-1 w-fit">
        {(["records","scholarships"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-md text-xs font-medium capitalize transition-colors
              ${tab === t ? "bg-brand-500 text-white" : "text-[#7B8DB8] hover:text-[#EEF2FF]"}`}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === "records" && (
        <div className="card overflow-hidden">
          <div className="px-5 py-3 border-b border-[#1E2640] flex justify-between items-center">
            <span className="text-sm font-semibold text-[#EEF2FF]">Fee Records</span>
            <div className="flex gap-2 text-xs">
              <span className="badge-green">Paid: {summary?.paid_count ?? 0}</span>
              <span className="badge-gold">Partial: {summary?.partial_count ?? 0}</span>
              <span className="badge-red">Overdue: {summary?.overdue_count ?? 0}</span>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1E2640]">
                  {["Student ID","Total Due","Paid","Balance","Status"].map((h) => (
                    <th key={h} className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={5} className="text-center py-10 text-[#3E4C70]">Loading…</td></tr>
                ) : records.map((r, i) => {
                  const rec = r as Record<string, number | string>;
                  const balance = (rec.total_due_etb as number) - (rec.paid_etb as number);
                  return (
                    <tr key={i} className={`border-b border-[#1E2640] hover:bg-[#161C2E] ${i%2===1?"bg-[#161C2E]/30":""}`}>
                      <td className="px-4 py-2.5 font-mono text-xs text-brand-500">{rec.student_id}</td>
                      <td className="px-4 py-2.5 font-mono text-[#7B8DB8]">{fmtETB(rec.total_due_etb as number)}</td>
                      <td className="px-4 py-2.5 font-mono text-[#22C97A]">{fmtETB(rec.paid_etb as number)}</td>
                      <td className="px-4 py-2.5 font-mono" style={{ color: balance > 0 ? "#F04A4A" : "#22C97A" }}>
                        {fmtETB(balance)}
                      </td>
                      <td className="px-4 py-2.5">
                        <span className={STATUS_BADGE[rec.status as string] ?? "badge-blue"}>
                          {rec.status as string}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "scholarships" && (
        <div className="card overflow-hidden">
          <div className="px-5 py-3 border-b border-[#1E2640] text-sm font-semibold text-[#EEF2FF]">
            Active Scholarships ({scholarships.length})
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1E2640]">
                  {["Name","Amharic Name","Student ID","Amount (ETB)"].map((h) => (
                    <th key={h} className="text-left px-4 py-2.5 text-[10px] text-[#3E4C70] uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {scholarships.length === 0 ? (
                  <tr><td colSpan={4} className="text-center py-10 text-[#3E4C70]">No active scholarships</td></tr>
                ) : scholarships.map((s, i) => {
                  const sc = s as Record<string, unknown>;
                  return (
                    <tr key={i} className={`border-b border-[#1E2640] hover:bg-[#161C2E] ${i%2===1?"bg-[#161C2E]/30":""}`}>
                      <td className="px-4 py-2.5 text-[#EEF2FF]">{sc.name_en as string}</td>
                      <td className="px-4 py-2.5 text-[#7B8DB8] amharic text-xs">{(sc.name_am as string) ?? "—"}</td>
                      <td className="px-4 py-2.5 font-mono text-xs text-brand-500">{sc.student_id as string}</td>
                      <td className="px-4 py-2.5 font-mono text-[#22C97A]">{fmtETB(sc.amount_etb as number)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
