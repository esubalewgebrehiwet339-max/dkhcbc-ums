"use client";

import { useEffect, useState } from "react";
import { studentsApi } from "@/lib/api";
import type { Student } from "@/types";
import { toast } from "sonner";

const STATUS_BADGE: Record<string, string> = {
  active: "badge-green", probation: "badge-gold",
  suspended: "badge-red", withdrawn: "badge-purple",
};

export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const load = (q = "") => {
    studentsApi.list({ q, limit: 100 })
      .then((r) => setStudents(r.data))
      .catch(() => toast.error("Failed to load students"))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const filtered = students.filter(
    (s: Student & { status?: string }) =>
      filter === "all" || s.status === filter
  );

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold font-serif text-[#EEF2FF]">Student Registry</h1>
          <p className="text-sm text-[#7B8DB8] mt-0.5">{students.length} students</p>
        </div>
        <button className="btn-primary">+ Register Student</button>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <input
          className="input flex-1"
          placeholder="Search by name or ID…"
          value={search}
          onChange={(e) => { setSearch(e.target.value); load(e.target.value); }}
        />
        {["all","active","probation","suspended"].map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border capitalize transition-colors
              ${filter === f
                ? "bg-brand-500 text-white border-brand-500"
                : "bg-[#111520] text-[#7B8DB8] border-[#1E2640] hover:border-brand-500"
              }`}>
            {f}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1E2640]">
                {["Student ID","Full Name","Amharic Name","Gender","Sponsor","Status"].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] text-[#3E4C70] uppercase tracking-wider font-semibold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-12 text-[#3E4C70]">Loading…</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-[#3E4C70]">No students found</td></tr>
              ) : filtered.map((s: Student & { status?: string; user?: { first_name_en?: string; last_name_en?: string; first_name_am?: string; last_name_am?: string } }, i) => (
                <tr key={s.id}
                  className={`border-b border-[#1E2640] hover:bg-[#161C2E] transition-colors
                    ${i % 2 === 1 ? "bg-[#161C2E]/30" : ""}`}>
                  <td className="px-4 py-3 font-mono text-xs text-brand-500">{s.student_id}</td>
                  <td className="px-4 py-3 font-medium text-[#EEF2FF]">
                    {s.user?.first_name_en} {s.user?.last_name_en}
                  </td>
                  <td className="px-4 py-3 text-[#7B8DB8] amharic text-xs">
                    {s.user?.first_name_am} {s.user?.last_name_am}
                  </td>
                  <td className="px-4 py-3 text-[#7B8DB8]">{s.gender}</td>
                  <td className="px-4 py-3 text-[#7B8DB8] capitalize">{s.sponsor_type}</td>
                  <td className="px-4 py-3">
                    <span className={STATUS_BADGE[s.status ?? "active"] ?? "badge-blue"}>
                      {s.status ?? "active"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
