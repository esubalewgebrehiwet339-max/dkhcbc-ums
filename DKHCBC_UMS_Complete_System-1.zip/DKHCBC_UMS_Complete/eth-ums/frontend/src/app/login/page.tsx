"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success("Welcome back!");
      router.push("/dashboard");
    } catch {
      toast.error("Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A0D14]">
      {/* Background gradient */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-brand-500/5 blur-3xl" />
      </div>

      <div className="w-full max-w-md px-6">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-500 to-purple-600 text-2xl mb-4 shadow-lg shadow-brand-500/20">
            ✝
          </div>
          <h1 className="text-2xl font-bold font-serif text-[#EEF2FF]">
            DKHCBC UMS
          </h1>
          <p className="text-sm text-[#7B8DB8] mt-1">
            Debre Kidan Holy Cross Bible College
          </p>
          <p className="text-xs text-[#3E4C70] mt-0.5 amharic">
            ደብረ ቅዳን ቅዱስ መስቀል መጽሐፍ ቅዱስ ኮሌጅ
          </p>
        </div>

        {/* Card */}
        <div className="card p-8">
          <h2 className="text-lg font-semibold text-[#EEF2FF] mb-6">
            Sign in to your account
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#7B8DB8] mb-1.5 uppercase tracking-wide">
                Email Address
              </label>
              <input
                type="email"
                className="input"
                placeholder="admin@dkhcbc.edu.et"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#7B8DB8] mb-1.5 uppercase tracking-wide">
                Password
              </label>
              <input
                type="password"
                className="input"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full mt-2 py-2.5 flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in…
                </>
              ) : (
                "Sign In"
              )}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 pt-6 border-t border-[#1E2640]">
            <p className="text-xs text-[#3E4C70] mb-3 font-medium uppercase tracking-wide">
              Demo Credentials
            </p>
            <div className="space-y-1.5">
              {[
                ["Admin", "admin@dkhcbc.edu.et", "Admin@1234"],
                ["Registrar", "registrar@dkhcbc.edu.et", "Reg@1234"],
                ["Finance", "finance@dkhcbc.edu.et", "Fin@1234"],
                ["Professor", "prof.bekele@dkhcbc.edu.et", "Prof@1234"],
                ["Student", "abebe.kebede@dkhcbc.edu.et", "Stu@1234"],
              ].map(([role, e, p]) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => { setEmail(e); setPassword(p); }}
                  className="w-full text-left px-3 py-2 rounded-lg bg-[#161C2E] hover:bg-[#1E2640] transition-colors text-xs flex justify-between"
                >
                  <span className="text-[#7B8DB8] font-medium">{role}</span>
                  <span className="text-[#3E4C70] font-mono">{e}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-[#3E4C70] mt-6">
          University Management System v2.0 · 2016/17 E.C.
        </p>
      </div>
    </div>
  );
}
