// DKHCBC UMS — Shared TypeScript Types

export type UserRole =
  | "admin"
  | "registrar"
  | "finance"
  | "department_head"
  | "professor"
  | "librarian"
  | "student";

export interface User {
  id: number;
  email: string;
  role: UserRole;
  full_name_en: string;
  full_name_am?: string;
  university_id: number;
}

export interface Student {
  id: number;
  user_id: number;
  student_id: string;
  date_of_birth?: string;
  dob_ec?: string;
  gender?: string;
  region?: string;
  woreda?: string;
  kebele?: string;
  sponsor_type: string;
  emergency_name?: string;
  emergency_phone?: string;
  created_at: string;
}

export interface Faculty {
  id: number;
  user_id: number;
  department_id: number;
  employee_id: string;
  title?: string;
  specialization?: string;
  qualification?: string;
  hired_date?: string;
  is_active: boolean;
}

export interface Course {
  id: number;
  department_id: number;
  code: string;
  name_en: string;
  name_am?: string;
  section_group?: string;
  credit_hours: number;
  description?: string;
  is_active: boolean;
}

export interface Program {
  id: number;
  department_id: number;
  code: string;
  name_en: string;
  name_am?: string;
  degree_type: string;
  total_credits: number;
  duration_years: number;
  is_active: boolean;
}

export interface Grade {
  id: number;
  student_id: number;
  section_id: number;
  ca_score?: number;
  mid_score?: number;
  final_score?: number;
  total_score?: number;
  grade_symbol?: string;
  grade_points?: number;
  is_finalized: boolean;
}

export interface Enrollment {
  id: number;
  student_id: number;
  section_id: number;
  program_id: number;
  status: "active" | "withdrawn" | "graduated" | "suspended" | "probation";
  enrolled_at: string;
  approved_by?: number;
  approved_at?: string;
}

export interface FeeRecord {
  id: number;
  student_id: number;
  fee_structure_id: number;
  total_due_etb: number;
  paid_etb: number;
  status: "paid" | "partial" | "overdue" | "waived";
  due_date?: string;
}

export interface Payment {
  id: number;
  fee_record_id: number;
  amount_etb: number;
  payment_date: string;
  receipt_no?: string;
  method: string;
  notes?: string;
}

export interface Book {
  id: number;
  isbn?: string;
  title_en: string;
  title_am?: string;
  author: string;
  publisher?: string;
  year?: number;
  category?: string;
  total_copies: number;
  available: number;
  is_active: boolean;
}

export interface Notification {
  id: number;
  user_id?: number;
  title: string;
  title_am?: string;
  message: string;
  message_am?: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

export interface AuditLog {
  id: number;
  user_id?: number;
  action: string;
  resource: string;
  resource_id?: string;
  details?: string;
  ip_address?: string;
  created_at: string;
}

export interface DashboardData {
  students: { total: number; active: number };
  academic: { graded_courses: number; average_gpa: number };
  finance: {
    total_due_etb: number;
    total_paid_etb: number;
    outstanding_etb: number;
    collection_rate: number;
  };
  library: { active_loans: number };
}

export interface EnrollmentTrend {
  month: string;
  count: number;
}

export interface GpaDistribution {
  grade: string;
  count: number;
}

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  user: User;
}
