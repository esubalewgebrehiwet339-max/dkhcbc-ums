"""Initial migration — create all DKHCBC UMS tables

Revision ID: 0001_initial
Revises: 
Create Date: 2025-03-14
"""

from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Universities
    op.create_table(
        "universities",
        sa.Column("id",         sa.Integer,     primary_key=True),
        sa.Column("code",       sa.String(20),  unique=True, nullable=False),
        sa.Column("name_en",    sa.String(200),  nullable=False),
        sa.Column("name_am",    sa.String(200)),
        sa.Column("address",    sa.Text),
        sa.Column("region",     sa.String(100)),
        sa.Column("woreda",     sa.String(100)),
        sa.Column("kebele",     sa.String(100)),
        sa.Column("phone",      sa.String(30)),
        sa.Column("email",      sa.String(100)),
        sa.Column("website",    sa.String(200)),
        sa.Column("is_active",  sa.Boolean, default=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Users
    op.create_table(
        "users",
        sa.Column("id",             sa.Integer,    primary_key=True),
        sa.Column("university_id",  sa.Integer,    sa.ForeignKey("universities.id"), nullable=False),
        sa.Column("email",          sa.String(150), unique=True, nullable=False),
        sa.Column("password_hash",  sa.String(255), nullable=False),
        sa.Column("role",           sa.String(30),  nullable=False),
        sa.Column("first_name_en",  sa.String(100), nullable=False),
        sa.Column("last_name_en",   sa.String(100), nullable=False),
        sa.Column("first_name_am",  sa.String(100)),
        sa.Column("last_name_am",   sa.String(100)),
        sa.Column("phone",          sa.String(30)),
        sa.Column("is_active",      sa.Boolean, default=True),
        sa.Column("last_login",     sa.DateTime(timezone=True)),
        sa.Column("created_at",     sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",     sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_users_email", "users", ["email"])

    # Departments
    op.create_table(
        "departments",
        sa.Column("id",            sa.Integer,    primary_key=True),
        sa.Column("university_id", sa.Integer,    sa.ForeignKey("universities.id"), nullable=False),
        sa.Column("code",          sa.String(20),  nullable=False),
        sa.Column("name_en",       sa.String(200), nullable=False),
        sa.Column("name_am",       sa.String(200)),
        sa.Column("description",   sa.Text),
        sa.Column("head_id",       sa.Integer,    sa.ForeignKey("users.id")),
        sa.Column("is_active",     sa.Boolean, default=True),
        sa.Column("created_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("university_id", "code", name="uq_dept_univ_code"),
    )

    # Programs
    op.create_table(
        "programs",
        sa.Column("id",             sa.Integer,    primary_key=True),
        sa.Column("department_id",  sa.Integer,    sa.ForeignKey("departments.id"), nullable=False),
        sa.Column("code",           sa.String(30),  unique=True, nullable=False),
        sa.Column("name_en",        sa.String(200), nullable=False),
        sa.Column("name_am",        sa.String(200)),
        sa.Column("degree_type",    sa.String(50),  default="Diploma"),
        sa.Column("total_credits",  sa.Integer,    default=90),
        sa.Column("duration_years", sa.Integer,    default=2),
        sa.Column("is_active",      sa.Boolean,    default=True),
        sa.Column("created_at",     sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",     sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Academic Years
    op.create_table(
        "academic_years",
        sa.Column("id",         sa.Integer,    primary_key=True),
        sa.Column("label_ec",   sa.String(20),  unique=True, nullable=False),
        sa.Column("label_gc",   sa.String(20)),
        sa.Column("start_date", sa.Date,        nullable=False),
        sa.Column("end_date",   sa.Date,        nullable=False),
        sa.Column("is_current", sa.Boolean,     default=False),
    )

    # Students
    op.create_table(
        "students",
        sa.Column("id",              sa.Integer,   primary_key=True),
        sa.Column("user_id",         sa.Integer,   sa.ForeignKey("users.id"), unique=True),
        sa.Column("student_id",      sa.String(30), unique=True, nullable=False),
        sa.Column("date_of_birth",   sa.Date),
        sa.Column("dob_ec",          sa.String(30)),
        sa.Column("gender",          sa.String(10)),
        sa.Column("region",          sa.String(100)),
        sa.Column("woreda",          sa.String(100)),
        sa.Column("kebele",          sa.String(100)),
        sa.Column("sponsor_type",    sa.String(20), default="self"),
        sa.Column("emergency_name",  sa.String(200)),
        sa.Column("emergency_phone", sa.String(30)),
        sa.Column("created_at",      sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",      sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_students_student_id", "students", ["student_id"])

    # Faculty
    op.create_table(
        "faculty",
        sa.Column("id",             sa.Integer,   primary_key=True),
        sa.Column("user_id",        sa.Integer,   sa.ForeignKey("users.id"), unique=True),
        sa.Column("department_id",  sa.Integer,   sa.ForeignKey("departments.id")),
        sa.Column("employee_id",    sa.String(30), unique=True, nullable=False),
        sa.Column("title",          sa.String(50)),
        sa.Column("specialization", sa.String(200)),
        sa.Column("qualification",  sa.String(200)),
        sa.Column("hired_date",     sa.Date),
        sa.Column("is_active",      sa.Boolean,   default=True),
        sa.Column("created_at",     sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",     sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Courses
    op.create_table(
        "courses",
        sa.Column("id",            sa.Integer,    primary_key=True),
        sa.Column("department_id", sa.Integer,    sa.ForeignKey("departments.id")),
        sa.Column("code",          sa.String(20),  unique=True, nullable=False),
        sa.Column("name_en",       sa.String(300), nullable=False),
        sa.Column("name_am",       sa.String(300)),
        sa.Column("section_group", sa.String(100)),
        sa.Column("credit_hours",  sa.Integer,    default=3),
        sa.Column("description",   sa.Text),
        sa.Column("is_active",     sa.Boolean,    default=True),
        sa.Column("created_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Course Sections
    op.create_table(
        "course_sections",
        sa.Column("id",               sa.Integer,  primary_key=True),
        sa.Column("course_id",        sa.Integer,  sa.ForeignKey("courses.id")),
        sa.Column("instructor_id",    sa.Integer,  sa.ForeignKey("faculty.id")),
        sa.Column("academic_year_id", sa.Integer,  sa.ForeignKey("academic_years.id")),
        sa.Column("semester",         sa.String(20)),
        sa.Column("section_code",     sa.String(10), default="A"),
        sa.Column("max_students",     sa.Integer,  default=30),
        sa.Column("room",             sa.String(50)),
        sa.Column("schedule",         sa.String(200)),
        sa.Column("created_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Enrollments
    op.create_table(
        "enrollments",
        sa.Column("id",          sa.Integer,  primary_key=True),
        sa.Column("student_id",  sa.Integer,  sa.ForeignKey("students.id")),
        sa.Column("section_id",  sa.Integer,  sa.ForeignKey("course_sections.id")),
        sa.Column("program_id",  sa.Integer,  sa.ForeignKey("programs.id")),
        sa.Column("status",      sa.String(20), default="active"),
        sa.Column("enrolled_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("approved_by", sa.Integer,  sa.ForeignKey("users.id")),
        sa.Column("approved_at", sa.DateTime(timezone=True)),
        sa.Column("created_at",  sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",  sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("student_id", "section_id", name="uq_enrollment"),
    )

    # Grades
    op.create_table(
        "grades",
        sa.Column("id",           sa.Integer,  primary_key=True),
        sa.Column("student_id",   sa.Integer,  sa.ForeignKey("students.id")),
        sa.Column("section_id",   sa.Integer,  sa.ForeignKey("course_sections.id")),
        sa.Column("ca_score",     sa.Numeric(5, 2)),
        sa.Column("mid_score",    sa.Numeric(5, 2)),
        sa.Column("final_score",  sa.Numeric(5, 2)),
        sa.Column("total_score",  sa.Numeric(5, 2)),
        sa.Column("grade_symbol", sa.String(5)),
        sa.Column("grade_points", sa.Numeric(4, 2)),
        sa.Column("is_finalized", sa.Boolean, default=False),
        sa.Column("submitted_by", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("created_at",   sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",   sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("student_id", "section_id", name="uq_grade"),
    )

    # Fee Structures
    op.create_table(
        "fee_structures",
        sa.Column("id",               sa.Integer,       primary_key=True),
        sa.Column("program_id",       sa.Integer,       sa.ForeignKey("programs.id")),
        sa.Column("academic_year_id", sa.Integer,       sa.ForeignKey("academic_years.id")),
        sa.Column("tuition_etb",      sa.Numeric(10,2), nullable=False),
        sa.Column("registration_etb", sa.Numeric(10,2), default=0),
        sa.Column("other_fees_etb",   sa.Numeric(10,2), default=0),
        sa.Column("description",      sa.Text),
        sa.Column("created_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Fee Records
    op.create_table(
        "fee_records",
        sa.Column("id",               sa.Integer,       primary_key=True),
        sa.Column("student_id",       sa.Integer,       sa.ForeignKey("students.id")),
        sa.Column("fee_structure_id", sa.Integer,       sa.ForeignKey("fee_structures.id")),
        sa.Column("total_due_etb",    sa.Numeric(10,2)),
        sa.Column("paid_etb",         sa.Numeric(10,2), default=0),
        sa.Column("status",           sa.String(20),    default="overdue"),
        sa.Column("due_date",         sa.Date),
        sa.Column("created_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Payments
    op.create_table(
        "payments",
        sa.Column("id",            sa.Integer,       primary_key=True),
        sa.Column("fee_record_id", sa.Integer,       sa.ForeignKey("fee_records.id")),
        sa.Column("amount_etb",    sa.Numeric(10,2)),
        sa.Column("payment_date",  sa.Date,          nullable=False),
        sa.Column("receipt_no",    sa.String(50)),
        sa.Column("method",        sa.String(50),    default="cash"),
        sa.Column("recorded_by",   sa.Integer,       sa.ForeignKey("users.id")),
        sa.Column("notes",         sa.Text),
        sa.Column("created_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Scholarships
    op.create_table(
        "scholarships",
        sa.Column("id",               sa.Integer,       primary_key=True),
        sa.Column("student_id",       sa.Integer,       sa.ForeignKey("students.id")),
        sa.Column("name_en",          sa.String(200)),
        sa.Column("name_am",          sa.String(200)),
        sa.Column("amount_etb",       sa.Numeric(10,2)),
        sa.Column("academic_year_id", sa.Integer,       sa.ForeignKey("academic_years.id")),
        sa.Column("is_active",        sa.Boolean,       default=True),
        sa.Column("notes",            sa.Text),
        sa.Column("created_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",       sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Books
    op.create_table(
        "books",
        sa.Column("id",            sa.Integer,    primary_key=True),
        sa.Column("isbn",          sa.String(20),  unique=True),
        sa.Column("title_en",      sa.String(400), nullable=False),
        sa.Column("title_am",      sa.String(400)),
        sa.Column("author",        sa.String(300), nullable=False),
        sa.Column("publisher",     sa.String(200)),
        sa.Column("year",          sa.Integer),
        sa.Column("category",      sa.String(100)),
        sa.Column("total_copies",  sa.Integer,    default=1),
        sa.Column("available",     sa.Integer,    default=1),
        sa.Column("is_active",     sa.Boolean,    default=True),
        sa.Column("created_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",    sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Library Loans
    op.create_table(
        "library_loans",
        sa.Column("id",          sa.Integer,       primary_key=True),
        sa.Column("book_id",     sa.Integer,       sa.ForeignKey("books.id")),
        sa.Column("student_id",  sa.Integer,       sa.ForeignKey("students.id")),
        sa.Column("issued_at",   sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("due_date",    sa.Date,          nullable=False),
        sa.Column("returned_at", sa.DateTime(timezone=True)),
        sa.Column("status",      sa.String(20),    default="borrowed"),
        sa.Column("fine_etb",    sa.Numeric(8,2),  default=0),
        sa.Column("fine_paid",   sa.Boolean,       default=False),
        sa.Column("issued_by",   sa.Integer,       sa.ForeignKey("users.id")),
        sa.Column("created_at",  sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at",  sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Notifications
    op.create_table(
        "notifications",
        sa.Column("id",         sa.Integer,    primary_key=True),
        sa.Column("user_id",    sa.Integer,    sa.ForeignKey("users.id")),
        sa.Column("title",      sa.String(300), nullable=False),
        sa.Column("title_am",   sa.String(300)),
        sa.Column("message",    sa.Text,        nullable=False),
        sa.Column("message_am", sa.Text),
        sa.Column("type",       sa.String(50),  default="info"),
        sa.Column("is_read",    sa.Boolean,     default=False),
        sa.Column("sent_by",    sa.Integer,     sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Audit Logs
    op.create_table(
        "audit_logs",
        sa.Column("id",          sa.Integer,    primary_key=True),
        sa.Column("user_id",     sa.Integer,    sa.ForeignKey("users.id")),
        sa.Column("action",      sa.String(100), nullable=False),
        sa.Column("resource",    sa.String(100), nullable=False),
        sa.Column("resource_id", sa.String(50)),
        sa.Column("details",     sa.Text),
        sa.Column("ip_address",  sa.String(45)),
        sa.Column("user_agent",  sa.String(500)),
        sa.Column("created_at",  sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_audit_logs_user_id",    "audit_logs", ["user_id"])
    op.create_index("ix_audit_logs_created_at", "audit_logs", ["created_at"])


def downgrade() -> None:
    tables = [
        "audit_logs", "notifications", "library_loans", "books",
        "scholarships", "payments", "fee_records", "fee_structures",
        "grades", "enrollments", "course_sections", "courses",
        "faculty", "students", "academic_years", "programs",
        "departments", "users", "universities",
    ]
    for t in tables:
        op.drop_table(t)
