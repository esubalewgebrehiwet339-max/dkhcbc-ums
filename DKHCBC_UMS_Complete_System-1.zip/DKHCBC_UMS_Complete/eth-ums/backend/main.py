"""
DKHCBC UMS — FastAPI Application Entry Point
Debre Kidan Holy Cross Bible College · University Management System v2.0
"""

import structlog
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_fastapi_instrumentator import Instrumentator

from shared.config.settings import settings
from shared.config.database import create_tables
from shared.middleware.audit import AuditMiddleware
from shared.middleware.rate_limiter import RateLimitMiddleware

from services.auth.router        import router as auth_router
from services.student.router     import router as student_router
from services.faculty.router     import router as faculty_router
from services.academic.router    import router as academic_router
from services.registrar.router   import router as registrar_router
from services.finance.router     import router as finance_router
from services.library.router     import router as library_router
from services.notification.router import router as notification_router
from services.analytics.router   import router as analytics_router
from services.admin.router       import router as admin_router

log = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("DKHCBC UMS starting", version=settings.VERSION, env=settings.ENVIRONMENT)
    if settings.ENVIRONMENT == "development":
        await create_tables()
    yield
    log.info("DKHCBC UMS shutdown")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="Enterprise University Management System — DKHCBC",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

# ── Middleware ────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(AuditMiddleware)
app.add_middleware(RateLimitMiddleware)

# ── Prometheus Metrics ────────────────────────────────────────────────────────
Instrumentator().instrument(app).expose(app, endpoint="/metrics")

# ── Routers ───────────────────────────────────────────────────────────────────
PREFIX = "/api/v1"
app.include_router(auth_router,         prefix=f"{PREFIX}/auth",          tags=["Authentication"])
app.include_router(student_router,      prefix=f"{PREFIX}/students",       tags=["Students"])
app.include_router(faculty_router,      prefix=f"{PREFIX}/faculty",        tags=["Faculty"])
app.include_router(academic_router,     prefix=f"{PREFIX}/academic",       tags=["Academic"])
app.include_router(registrar_router,    prefix=f"{PREFIX}/registrar",      tags=["Registrar"])
app.include_router(finance_router,      prefix=f"{PREFIX}/finance",        tags=["Finance"])
app.include_router(library_router,      prefix=f"{PREFIX}/library",        tags=["Library"])
app.include_router(notification_router, prefix=f"{PREFIX}/notifications",  tags=["Notifications"])
app.include_router(analytics_router,    prefix=f"{PREFIX}/analytics",      tags=["Analytics"])
app.include_router(admin_router,        prefix=f"{PREFIX}/admin",          tags=["Admin"])


@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "version": settings.VERSION, "service": settings.APP_NAME}
