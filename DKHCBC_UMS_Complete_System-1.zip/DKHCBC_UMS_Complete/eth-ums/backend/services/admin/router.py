"""Admin service — user management, audit logs, system config."""

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel, EmailStr

from shared.config.database import get_db
from shared.models.orm_models import User, AuditLog, University, Department, UserRole
from services.auth.router import get_current_user, require_roles, hash_password

router = APIRouter()
ADMIN_ONLY = require_roles(UserRole.ADMIN)


class UserCreate(BaseModel):
    university_id: int
    email: EmailStr
    password: str
    role: UserRole
    first_name_en: str
    last_name_en: str
    first_name_am: Optional[str] = None
    last_name_am: Optional[str] = None
    phone: Optional[str] = None

class UserUpdate(BaseModel):
    first_name_en: Optional[str] = None
    last_name_en: Optional[str] = None
    first_name_am: Optional[str] = None
    last_name_am: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None
    role: Optional[UserRole] = None


# ── Users ─────────────────────────────────────────────────────────────────────

@router.get("/users")
async def list_users(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(ADMIN_ONLY)],
    role: Optional[str] = Query(None),
    q: Optional[str] = Query(None),
    skip: int = 0, limit: int = 100,
):
    query = select(User)
    if role:
        query = query.where(User.role == role)
    if q:
        query = query.where(
            (User.email.ilike(f"%{q}%")) |
            (User.first_name_en.ilike(f"%{q}%")) |
            (User.last_name_en.ilike(f"%{q}%"))
        )
    result = await db.execute(query.offset(skip).limit(limit))
    users = result.scalars().all()
    # Remove password hashes
    return [
        {k: v for k, v in u.__dict__.items() if k != "password_hash" and not k.startswith("_")}
        for u in users
    ]

@router.post("/users", status_code=201)
async def create_user(
    body: UserCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(ADMIN_ONLY)],
):
    existing = await db.execute(select(User).where(User.email == body.email))
    if existing.scalar_one_or_none():
        raise HTTPException(400, f"Email {body.email} already registered")

    user = User(
        **{k: v for k, v in body.model_dump().items() if k != "password"},
        password_hash=hash_password(body.password),
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return {k: v for k, v in user.__dict__.items() if k != "password_hash" and not k.startswith("_")}

@router.patch("/users/{user_id}")
async def update_user(
    user_id: int,
    body: UserUpdate,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(ADMIN_ONLY)],
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User not found")
    for field, value in body.model_dump(exclude_none=True).items():
        setattr(user, field, value)
    await db.commit()
    return {"status": "updated", "user_id": user_id}

@router.delete("/users/{user_id}", status_code=204)
async def deactivate_user(
    user_id: int,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(ADMIN_ONLY)],
):
    if user_id == current_user.id:
        raise HTTPException(400, "Cannot deactivate yourself")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User not found")
    user.is_active = False
    await db.commit()


# ── Audit Log ─────────────────────────────────────────────────────────────────

@router.get("/audit-logs")
async def get_audit_logs(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(ADMIN_ONLY)],
    skip: int = 0, limit: int = 100,
):
    result = await db.execute(
        select(AuditLog).order_by(AuditLog.created_at.desc()).offset(skip).limit(limit)
    )
    return result.scalars().all()


# ── Universities & Departments ────────────────────────────────────────────────

@router.get("/universities")
async def list_universities(db: Annotated[AsyncSession, Depends(get_db)],
                             _: Annotated[User, Depends(ADMIN_ONLY)]):
    result = await db.execute(select(University))
    return result.scalars().all()

@router.get("/departments")
async def list_departments(db: Annotated[AsyncSession, Depends(get_db)],
                            _: Annotated[User, Depends(ADMIN_ONLY)],
                            university_id: Optional[int] = Query(None)):
    q = select(Department)
    if university_id:
        q = q.where(Department.university_id == university_id)
    result = await db.execute(q)
    return result.scalars().all()


# ── System Stats ──────────────────────────────────────────────────────────────

@router.get("/system-stats")
async def system_stats(db: Annotated[AsyncSession, Depends(get_db)],
                        _: Annotated[User, Depends(ADMIN_ONLY)]):
    user_count = await db.scalar(select(func.count(User.id)).where(User.is_active == True))
    role_counts = {}
    for role in UserRole:
        cnt = await db.scalar(select(func.count(User.id)).where(User.role == role))
        role_counts[role.value] = cnt or 0
    return {
        "total_active_users": user_count or 0,
        "by_role": role_counts,
        "version": "2.0.0",
    }
