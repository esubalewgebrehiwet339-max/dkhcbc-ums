"""Finance service — fee structures, payments (ETB), scholarships."""

from typing import Annotated, Optional
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from datetime import date

from shared.config.database import get_db
from shared.models.orm_models import (
    FeeStructure, FeeRecord, Payment, Scholarship,
    Student, User, UserRole, PaymentStatus
)
from services.auth.router import get_current_user, require_roles

router = APIRouter()

FINANCE_ACCESS = require_roles(UserRole.ADMIN, UserRole.FINANCE)


class PaymentCreate(BaseModel):
    fee_record_id: int
    amount_etb: float
    payment_date: date
    receipt_no: Optional[str] = None
    method: str = "cash"
    notes: Optional[str] = None

class ScholarshipCreate(BaseModel):
    student_id: int
    name_en: str
    name_am: Optional[str] = None
    amount_etb: float
    academic_year_id: int
    notes: Optional[str] = None


# ── Fee Structures ────────────────────────────────────────────────────────────

@router.get("/fee-structures")
async def list_fee_structures(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(select(FeeStructure))
    return result.scalars().all()

@router.get("/fee-structures/{structure_id}")
async def get_fee_structure(structure_id: int,
                            db: Annotated[AsyncSession, Depends(get_db)],
                            _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(select(FeeStructure).where(FeeStructure.id == structure_id))
    fs = result.scalar_one_or_none()
    if not fs:
        raise HTTPException(404, "Fee structure not found")
    return fs


# ── Fee Records ───────────────────────────────────────────────────────────────

@router.get("/records")
async def list_fee_records(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(FINANCE_ACCESS)],
    status: Optional[str] = Query(None),
    skip: int = 0,
    limit: int = 50,
):
    q = select(FeeRecord)
    if status:
        q = q.where(FeeRecord.status == status)
    result = await db.execute(q.offset(skip).limit(limit))
    return result.scalars().all()

@router.get("/records/student/{student_id}")
async def student_fee_records(
    student_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    st_result = await db.execute(select(Student).where(Student.student_id == student_id))
    student = st_result.scalar_one_or_none()
    if not student:
        raise HTTPException(404, "Student not found")
    if current_user.role == UserRole.STUDENT and student.user_id != current_user.id:
        raise HTTPException(403, "Access denied")
    result = await db.execute(select(FeeRecord).where(FeeRecord.student_id == student.id))
    return result.scalars().all()


# ── Payments ──────────────────────────────────────────────────────────────────

@router.post("/payments", status_code=201)
async def record_payment(
    body: PaymentCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(FINANCE_ACCESS)],
):
    # Load fee record
    fr_result = await db.execute(select(FeeRecord).where(FeeRecord.id == body.fee_record_id))
    fee_record = fr_result.scalar_one_or_none()
    if not fee_record:
        raise HTTPException(404, "Fee record not found")

    payment = Payment(
        fee_record_id=body.fee_record_id,
        amount_etb=Decimal(str(body.amount_etb)),
        payment_date=body.payment_date,
        receipt_no=body.receipt_no,
        method=body.method,
        notes=body.notes,
        recorded_by=current_user.id,
    )
    db.add(payment)

    # Update fee record paid amount and status
    fee_record.paid_etb = (fee_record.paid_etb or Decimal(0)) + Decimal(str(body.amount_etb))
    if fee_record.paid_etb >= fee_record.total_due_etb:
        fee_record.status = PaymentStatus.PAID
    elif fee_record.paid_etb > 0:
        fee_record.status = PaymentStatus.PARTIAL

    await db.commit()
    await db.refresh(payment)
    return payment


# ── Scholarships ──────────────────────────────────────────────────────────────

@router.get("/scholarships")
async def list_scholarships(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(FINANCE_ACCESS)],
):
    result = await db.execute(select(Scholarship).where(Scholarship.is_active == True))
    return result.scalars().all()

@router.post("/scholarships", status_code=201)
async def create_scholarship(
    body: ScholarshipCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(FINANCE_ACCESS)],
):
    scholarship = Scholarship(
        student_id=body.student_id,
        name_en=body.name_en,
        name_am=body.name_am,
        amount_etb=Decimal(str(body.amount_etb)),
        academic_year_id=body.academic_year_id,
        notes=body.notes,
    )
    db.add(scholarship)
    await db.commit()
    await db.refresh(scholarship)
    return scholarship


# ── Summary / KPIs ────────────────────────────────────────────────────────────

@router.get("/summary")
async def finance_summary(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(FINANCE_ACCESS)],
):
    total_due   = await db.scalar(select(func.sum(FeeRecord.total_due_etb)))
    total_paid  = await db.scalar(select(func.sum(FeeRecord.paid_etb)))
    paid_count  = await db.scalar(select(func.count()).where(FeeRecord.status == "paid"))
    partial_count = await db.scalar(select(func.count()).where(FeeRecord.status == "partial"))
    overdue_count = await db.scalar(select(func.count()).where(FeeRecord.status == "overdue"))
    scholarship_count = await db.scalar(select(func.count()).where(Scholarship.is_active == True))

    total_due  = float(total_due  or 0)
    total_paid = float(total_paid or 0)

    return {
        "total_due_etb":       total_due,
        "total_paid_etb":      total_paid,
        "outstanding_etb":     total_due - total_paid,
        "collection_rate_pct": round(total_paid / total_due * 100, 1) if total_due else 0,
        "paid_count":          paid_count or 0,
        "partial_count":       partial_count or 0,
        "overdue_count":       overdue_count or 0,
        "scholarship_count":   scholarship_count or 0,
        "currency":            "ETB",
    }
