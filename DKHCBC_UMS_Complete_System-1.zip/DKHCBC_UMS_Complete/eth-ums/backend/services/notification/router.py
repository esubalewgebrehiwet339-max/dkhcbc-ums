"""Notification service — user and broadcast notifications."""

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from shared.config.database import get_db
from shared.models.orm_models import Notification, User, UserRole
from services.auth.router import get_current_user, require_roles

router = APIRouter()


class NotificationCreate(BaseModel):
    user_id: Optional[int] = None  # None = broadcast to all
    title: str
    title_am: Optional[str] = None
    message: str
    message_am: Optional[str] = None
    type: str = "info"  # info | warning | success | error


@router.get("")
async def get_my_notifications(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
    unread_only: bool = False,
):
    q = select(Notification).where(
        (Notification.user_id == current_user.id) | (Notification.user_id == None)
    )
    if unread_only:
        q = q.where(Notification.is_read == False)
    result = await db.execute(q.order_by(Notification.created_at.desc()).limit(50))
    return result.scalars().all()

@router.post("", status_code=201)
async def create_notification(
    body: NotificationCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(require_roles(UserRole.ADMIN, UserRole.REGISTRAR))],
):
    notif = Notification(**body.model_dump(), sent_by=current_user.id)
    db.add(notif)
    await db.commit()
    await db.refresh(notif)
    return notif

@router.patch("/{notif_id}/read")
async def mark_read(
    notif_id: int,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(select(Notification).where(Notification.id == notif_id))
    notif = result.scalar_one_or_none()
    if not notif:
        raise HTTPException(404, "Notification not found")
    notif.is_read = True
    await db.commit()
    return {"status": "read", "id": notif_id}

@router.delete("/{notif_id}", status_code=204)
async def delete_notification(
    notif_id: int,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(select(Notification).where(Notification.id == notif_id))
    notif = result.scalar_one_or_none()
    if not notif:
        raise HTTPException(404, "Notification not found")
    await db.delete(notif)
    await db.commit()

@router.patch("/mark-all-read")
async def mark_all_read(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(
        select(Notification).where(
            ((Notification.user_id == current_user.id) | (Notification.user_id == None)),
            Notification.is_read == False,
        )
    )
    notifs = result.scalars().all()
    for n in notifs:
        n.is_read = True
    await db.commit()
    return {"status": "ok", "marked_read": len(notifs)}
