"""Student service — profiles, history, personal dashboard data."""

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from shared.config.database import get_db
from shared.models.orm_models import Student, User, Enrollment, Grade, UserRole
from services.auth.router import get_current_user, require_roles

router = APIRouter()


class StudentCreate(BaseModel):
    user_id: int
    student_id: str
    date_of_birth: Optional[str] = None
    dob_ec: Optional[str] = None
    gender: Optional[str] = None
    region: Optional[str] = None
    woreda: Optional[str] = None
    kebele: Optional[str] = None
    sponsor_type: str = "self"
    emergency_name: Optional[str] = None
    emergency_phone: Optional[str] = None

class StudentUpdate(BaseModel):
    phone: Optional[str] = None
    region: Optional[str] = None
    woreda: Optional[str] = None
    kebele: Optional[str] = None
    emergency_name: Optional[str] = None
    emergency_phone: Optional[str] = None


@router.get("")
async def list_students(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(require_roles(UserRole.ADMIN, UserRole.REGISTRAR, UserRole.FINANCE))],
    q: Optional[str] = Query(None),
    skip: int = 0,
    limit: int = 50,
):
    query = select(Student).join(User)
    if q:
        query = query.where(
            (User.first_name_en.ilike(f"%{q}%")) |
            (User.last_name_en.ilike(f"%{q}%")) |
            (Student.student_id.ilike(f"%{q}%"))
        )
    result = await db.execute(query.offset(skip).limit(limit))
    students = result.scalars().all()
    return students

@router.post("", status_code=201)
async def create_student(
    body: StudentCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(require_roles(UserRole.ADMIN, UserRole.REGISTRAR))],
):
    student = Student(**body.model_dump())
    db.add(student)
    await db.commit()
    await db.refresh(student)
    return student

@router.get("/{student_id}")
async def get_student(
    student_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(select(Student).where(Student.student_id == student_id))
    student = result.scalar_one_or_none()
    if not student:
        raise HTTPException(404, f"Student {student_id} not found")
    # Students can only view their own profile
    if current_user.role == UserRole.STUDENT and student.user_id != current_user.id:
        raise HTTPException(403, "Access denied")
    return student

@router.patch("/{student_id}")
async def update_student(
    student_id: str,
    body: StudentUpdate,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(select(Student).where(Student.student_id == student_id))
    student = result.scalar_one_or_none()
    if not student:
        raise HTTPException(404, f"Student {student_id} not found")
    if current_user.role == UserRole.STUDENT and student.user_id != current_user.id:
        raise HTTPException(403, "Access denied")
    for field, value in body.model_dump(exclude_none=True).items():
        setattr(student, field, value)
    await db.commit()
    await db.refresh(student)
    return student

@router.get("/{student_id}/enrollments")
async def student_enrollments(
    student_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(select(Student).where(Student.student_id == student_id))
    student = result.scalar_one_or_none()
    if not student:
        raise HTTPException(404, "Student not found")
    enroll_result = await db.execute(
        select(Enrollment).where(Enrollment.student_id == student.id)
    )
    return enroll_result.scalars().all()
