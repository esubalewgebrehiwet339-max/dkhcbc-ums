"""Analytics service — dashboards, KPIs, performance metrics."""

from typing import Annotated
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from shared.config.database import get_db
from shared.models.orm_models import (
    Student, User, Grade, Enrollment, FeeRecord,
    LibraryLoan, AuditLog, UserRole, EnrollmentStatus
)
from services.auth.router import get_current_user, require_roles

router = APIRouter()
STAFF = require_roles(UserRole.ADMIN, UserRole.REGISTRAR, UserRole.FINANCE,
                      UserRole.DEPARTMENT_HEAD, UserRole.LIBRARIAN)


@router.get("/dashboard")
async def admin_dashboard(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(STAFF)],
):
    """Aggregate KPIs for the admin dashboard."""
    total_students  = await db.scalar(select(func.count(Student.id)))
    active_students = await db.scalar(
        select(func.count(Enrollment.id)).where(Enrollment.status == "active")
    )
    total_grades    = await db.scalar(select(func.count(Grade.id)).where(Grade.is_finalized == True))
    avg_gpa         = await db.scalar(select(func.avg(Grade.grade_points)).where(Grade.is_finalized == True))
    overdue_loans   = await db.scalar(
        select(func.count(LibraryLoan.id)).where(LibraryLoan.status == "borrowed")
    )
    total_due_etb   = await db.scalar(select(func.sum(FeeRecord.total_due_etb)))
    total_paid_etb  = await db.scalar(select(func.sum(FeeRecord.paid_etb)))

    return {
        "students": {
            "total":  int(total_students or 0),
            "active": int(active_students or 0),
        },
        "academic": {
            "graded_courses":  int(total_grades or 0),
            "average_gpa":     round(float(avg_gpa or 0), 2),
        },
        "finance": {
            "total_due_etb":   float(total_due_etb or 0),
            "total_paid_etb":  float(total_paid_etb or 0),
            "outstanding_etb": float((total_due_etb or 0) - (total_paid_etb or 0)),
            "collection_rate": round(
                float(total_paid_etb or 0) / float(total_due_etb or 1) * 100, 1
            ),
        },
        "library": {
            "active_loans":  int(overdue_loans or 0),
        },
    }


@router.get("/enrollment-trends")
async def enrollment_trends(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(STAFF)],
):
    """Monthly enrollment counts for chart rendering."""
    result = await db.execute(
        select(
            func.date_trunc("month", Enrollment.enrolled_at).label("month"),
            func.count(Enrollment.id).label("count"),
        )
        .group_by("month")
        .order_by("month")
        .limit(12)
    )
    return [{"month": str(row.month)[:7], "count": row.count} for row in result]


@router.get("/gpa-distribution")
async def gpa_distribution(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(STAFF)],
):
    """Grade symbol distribution across all finalized grades."""
    result = await db.execute(
        select(Grade.grade_symbol, func.count(Grade.id).label("count"))
        .where(Grade.is_finalized == True)
        .group_by(Grade.grade_symbol)
        .order_by(Grade.grade_symbol)
    )
    return [{"grade": row.grade_symbol, "count": row.count} for row in result]


@router.get("/finance-monthly")
async def finance_monthly(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(require_roles(UserRole.ADMIN, UserRole.FINANCE))],
):
    """Monthly payment totals in ETB."""
    from shared.models.orm_models import Payment
    result = await db.execute(
        select(
            func.date_trunc("month", func.cast(Payment.payment_date, func.Date)).label("month"),
            func.sum(Payment.amount_etb).label("total"),
        )
        .group_by("month")
        .order_by("month")
        .limit(12)
    )
    return [{"month": str(row.month)[:7], "total_etb": float(row.total)} for row in result]
