"""Academic service — programs, courses, sections, enrollment, GPA."""

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel

from shared.config.database import get_db
from shared.models.orm_models import (
    Course, CourseSection, Program, AcademicYear,
    Enrollment, Grade, Student, User, UserRole
)
from services.auth.router import get_current_user, require_roles
from shared.utils.gpa_calculator import compute_cgpa, gpa_standing, score_to_grade

router = APIRouter()

ANY_STAFF = require_roles(
    UserRole.ADMIN, UserRole.REGISTRAR, UserRole.DEPARTMENT_HEAD,
    UserRole.PROFESSOR, UserRole.FINANCE
)


# ── Schemas ───────────────────────────────────────────────────────────────────

class CourseCreate(BaseModel):
    code: str
    name_en: str
    name_am: Optional[str] = None
    section_group: Optional[str] = None
    credit_hours: int = 3
    department_id: int
    description: Optional[str] = None

class GradeSubmit(BaseModel):
    student_id: int
    section_id: int
    ca_score: Optional[float] = None
    mid_score: Optional[float] = None
    final_score: Optional[float] = None


# ── Programs ──────────────────────────────────────────────────────────────────

@router.get("/programs")
async def list_programs(db: Annotated[AsyncSession, Depends(get_db)],
                        _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(select(Program).where(Program.is_active == True))
    return result.scalars().all()

@router.get("/programs/{program_id}")
async def get_program(program_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                      _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(select(Program).where(Program.id == program_id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(404, "Program not found")
    return p


# ── Courses ───────────────────────────────────────────────────────────────────

@router.get("/courses")
async def list_courses(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(get_current_user)],
    department_id: Optional[int] = Query(None),
    section_group: Optional[str] = Query(None),
):
    q = select(Course).where(Course.is_active == True)
    if department_id:
        q = q.where(Course.department_id == department_id)
    if section_group:
        q = q.where(Course.section_group == section_group)
    result = await db.execute(q.order_by(Course.id))
    return result.scalars().all()

@router.post("/courses", status_code=201)
async def create_course(body: CourseCreate,
                        db: Annotated[AsyncSession, Depends(get_db)],
                        _: Annotated[User, Depends(require_roles(UserRole.ADMIN, UserRole.DEPARTMENT_HEAD))]):
    course = Course(**body.model_dump())
    db.add(course)
    await db.commit()
    await db.refresh(course)
    return course

@router.get("/courses/{course_id}")
async def get_course(course_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                     _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(select(Course).where(Course.id == course_id))
    c = result.scalar_one_or_none()
    if not c:
        raise HTTPException(404, "Course not found")
    return c


# ── Sections ──────────────────────────────────────────────────────────────────

@router.get("/sections")
async def list_sections(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(get_current_user)],
    academic_year_id: Optional[int] = Query(None),
    instructor_id: Optional[int] = Query(None),
):
    q = select(CourseSection)
    if academic_year_id:
        q = q.where(CourseSection.academic_year_id == academic_year_id)
    if instructor_id:
        q = q.where(CourseSection.instructor_id == instructor_id)
    result = await db.execute(q)
    return result.scalars().all()

@router.get("/sections/{section_id}/students")
async def section_students(section_id: int,
                           db: Annotated[AsyncSession, Depends(get_db)],
                           _: Annotated[User, Depends(ANY_STAFF)]):
    result = await db.execute(
        select(Student).join(Enrollment).where(
            Enrollment.section_id == section_id,
            Enrollment.status == "active"
        )
    )
    return result.scalars().all()


# ── Grades ────────────────────────────────────────────────────────────────────

@router.post("/grades", status_code=201)
async def submit_grade(
    body: GradeSubmit,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(require_roles(
        UserRole.PROFESSOR, UserRole.ADMIN, UserRole.REGISTRAR
    ))],
):
    # Check for existing grade
    result = await db.execute(
        select(Grade).where(
            Grade.student_id == body.student_id,
            Grade.section_id == body.section_id,
        )
    )
    grade = result.scalar_one_or_none()

    total = None
    symbol = None
    points = None
    if body.ca_score is not None and body.mid_score is not None and body.final_score is not None:
        total = body.ca_score * 0.30 + body.mid_score * 0.30 + body.final_score * 0.40
        symbol, points = score_to_grade(total)

    if grade:
        grade.ca_score = body.ca_score
        grade.mid_score = body.mid_score
        grade.final_score = body.final_score
        grade.total_score = total
        grade.grade_symbol = symbol
        grade.grade_points = points
        grade.submitted_by = current_user.id
    else:
        grade = Grade(
            student_id=body.student_id, section_id=body.section_id,
            ca_score=body.ca_score, mid_score=body.mid_score,
            final_score=body.final_score, total_score=total,
            grade_symbol=symbol, grade_points=points,
            submitted_by=current_user.id,
        )
        db.add(grade)

    await db.commit()
    await db.refresh(grade)
    return grade

@router.patch("/grades/{grade_id}/finalize")
async def finalize_grade(grade_id: int,
                         db: Annotated[AsyncSession, Depends(get_db)],
                         _: Annotated[User, Depends(require_roles(UserRole.REGISTRAR, UserRole.ADMIN))]):
    result = await db.execute(select(Grade).where(Grade.id == grade_id))
    grade = result.scalar_one_or_none()
    if not grade:
        raise HTTPException(404, "Grade not found")
    grade.is_finalized = True
    await db.commit()
    return {"status": "finalized", "grade_id": grade_id}


# ── Student GPA ───────────────────────────────────────────────────────────────

@router.get("/students/{student_id}/gpa")
async def student_gpa(
    student_id: int,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(get_current_user)],
):
    result = await db.execute(
        select(Grade, Course)
        .join(CourseSection, Grade.section_id == CourseSection.id)
        .join(Course, CourseSection.course_id == Course.id)
        .where(Grade.student_id == student_id, Grade.is_finalized == True)
    )
    rows = result.all()
    if not rows:
        return {"cgpa": 0.0, "standing_en": "N/A", "standing_am": "N/A", "total_credits": 0}

    courses_data = [
        {"credit_hours": course.credit_hours, "grade_points": float(grade.grade_points or 0)}
        for grade, course in rows
    ]
    cgpa = compute_cgpa(courses_data)
    standing_en, standing_am = gpa_standing(cgpa)
    total_credits = sum(c["credit_hours"] for c in courses_data)

    return {
        "cgpa": cgpa,
        "standing_en": standing_en,
        "standing_am": standing_am,
        "total_credits": total_credits,
        "total_courses": len(rows),
        "grades": [
            {
                "course_code": course.code,
                "course_name_en": course.name_en,
                "course_name_am": course.name_am,
                "credit_hours": course.credit_hours,
                "grade_symbol": grade.grade_symbol,
                "grade_points": float(grade.grade_points or 0),
            }
            for grade, course in rows
        ],
    }
