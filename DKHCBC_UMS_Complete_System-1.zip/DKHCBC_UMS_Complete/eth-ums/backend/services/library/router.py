"""Library service — book catalog, loans, overdue fines (ETB 2/day)."""

from typing import Annotated, Optional
from decimal import Decimal
from datetime import date, datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel

from shared.config.database import get_db
from shared.models.orm_models import Book, LibraryLoan, Student, User, UserRole, LoanStatus
from services.auth.router import get_current_user, require_roles

router = APIRouter()
LIB_ACCESS = require_roles(UserRole.ADMIN, UserRole.LIBRARIAN)
FINE_PER_DAY = Decimal("2.00")  # ETB 2 per day overdue


class BookCreate(BaseModel):
    isbn: Optional[str] = None
    title_en: str
    title_am: Optional[str] = None
    author: str
    publisher: Optional[str] = None
    year: Optional[int] = None
    category: Optional[str] = None
    total_copies: int = 1

class LoanCreate(BaseModel):
    book_id: int
    student_id: int
    due_days: int = 14


# ── Books ─────────────────────────────────────────────────────────────────────

@router.get("/books")
async def list_books(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(get_current_user)],
    q: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    available_only: bool = False,
    skip: int = 0,
    limit: int = 50,
):
    query = select(Book).where(Book.is_active == True)
    if q:
        query = query.where(
            (Book.title_en.ilike(f"%{q}%")) | (Book.author.ilike(f"%{q}%"))
        )
    if category:
        query = query.where(Book.category == category)
    if available_only:
        query = query.where(Book.available > 0)
    result = await db.execute(query.offset(skip).limit(limit))
    return result.scalars().all()

@router.post("/books", status_code=201)
async def create_book(body: BookCreate, db: Annotated[AsyncSession, Depends(get_db)],
                      _: Annotated[User, Depends(LIB_ACCESS)]):
    book = Book(**body.model_dump(), available=body.total_copies)
    db.add(book)
    await db.commit()
    await db.refresh(book)
    return book

@router.get("/books/{book_id}")
async def get_book(book_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                   _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(select(Book).where(Book.id == book_id))
    book = result.scalar_one_or_none()
    if not book:
        raise HTTPException(404, "Book not found")
    return book


# ── Loans ─────────────────────────────────────────────────────────────────────

@router.post("/loans", status_code=201)
async def issue_loan(
    body: LoanCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(LIB_ACCESS)],
):
    book_result = await db.execute(select(Book).where(Book.id == body.book_id))
    book = book_result.scalar_one_or_none()
    if not book or book.available < 1:
        raise HTTPException(400, "Book not available")

    due_date = date.today() + timedelta(days=body.due_days)
    loan = LibraryLoan(
        book_id=body.book_id, student_id=body.student_id,
        due_date=due_date, issued_by=current_user.id,
    )
    book.available -= 1
    db.add(loan)
    await db.commit()
    await db.refresh(loan)
    return loan

@router.patch("/loans/{loan_id}/return")
async def return_book(loan_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                      _: Annotated[User, Depends(LIB_ACCESS)]):
    result = await db.execute(select(LibraryLoan).where(LibraryLoan.id == loan_id))
    loan = result.scalar_one_or_none()
    if not loan:
        raise HTTPException(404, "Loan not found")
    if loan.status == LoanStatus.RETURNED:
        raise HTTPException(400, "Already returned")

    today = date.today()
    loan.returned_at = datetime.utcnow()
    loan.status = LoanStatus.RETURNED

    if today > loan.due_date:
        overdue_days = (today - loan.due_date).days
        loan.fine_etb = FINE_PER_DAY * overdue_days

    book_result = await db.execute(select(Book).where(Book.id == loan.book_id))
    book = book_result.scalar_one_or_none()
    if book:
        book.available += 1

    await db.commit()
    return {"status": "returned", "fine_etb": float(loan.fine_etb), "loan_id": loan_id}

@router.get("/loans/overdue")
async def overdue_loans(db: Annotated[AsyncSession, Depends(get_db)],
                        _: Annotated[User, Depends(LIB_ACCESS)]):
    today = date.today()
    result = await db.execute(
        select(LibraryLoan).where(
            LibraryLoan.due_date < today,
            LibraryLoan.status == LoanStatus.BORROWED,
        )
    )
    loans = result.scalars().all()
    return [
        {**loan.__dict__, "overdue_days": (today - loan.due_date).days,
         "fine_etb": float(FINE_PER_DAY * (today - loan.due_date).days)}
        for loan in loans
    ]

@router.get("/summary")
async def library_summary(db: Annotated[AsyncSession, Depends(get_db)],
                           _: Annotated[User, Depends(get_current_user)]):
    total_books  = await db.scalar(select(func.sum(Book.total_copies)).where(Book.is_active == True))
    available    = await db.scalar(select(func.sum(Book.available)).where(Book.is_active == True))
    borrowed     = await db.scalar(select(func.count()).where(LibraryLoan.status == "borrowed"))
    overdue_count= await db.scalar(
        select(func.count()).where(
            LibraryLoan.status == "borrowed", LibraryLoan.due_date < date.today()
        )
    )
    return {
        "total_books": int(total_books or 0),
        "available": int(available or 0),
        "borrowed": int(borrowed or 0),
        "overdue": int(overdue_count or 0),
    }
