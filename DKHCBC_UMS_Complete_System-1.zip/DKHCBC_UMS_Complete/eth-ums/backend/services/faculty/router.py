"""Faculty service — profiles, workload, assignments."""

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from datetime import date

from shared.config.database import get_db
from shared.models.orm_models import Faculty, CourseSection, User, UserRole
from services.auth.router import get_current_user, require_roles

router = APIRouter()


class FacultyCreate(BaseModel):
    user_id: int
    department_id: int
    employee_id: str
    title: Optional[str] = None
    specialization: Optional[str] = None
    qualification: Optional[str] = None
    hired_date: Optional[date] = None

class FacultyUpdate(BaseModel):
    title: Optional[str] = None
    specialization: Optional[str] = None
    qualification: Optional[str] = None


@router.get("")
async def list_faculty(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(get_current_user)],
    department_id: Optional[int] = Query(None),
    skip: int = 0, limit: int = 50,
):
    q = select(Faculty).where(Faculty.is_active == True)
    if department_id:
        q = q.where(Faculty.department_id == department_id)
    result = await db.execute(q.offset(skip).limit(limit))
    return result.scalars().all()

@router.post("", status_code=201)
async def create_faculty(
    body: FacultyCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(require_roles(UserRole.ADMIN))],
):
    faculty = Faculty(**body.model_dump())
    db.add(faculty)
    await db.commit()
    await db.refresh(faculty)
    return faculty

@router.get("/{faculty_id}")
async def get_faculty(faculty_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                      _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(select(Faculty).where(Faculty.id == faculty_id))
    f = result.scalar_one_or_none()
    if not f:
        raise HTTPException(404, "Faculty not found")
    return f

@router.get("/{faculty_id}/sections")
async def faculty_sections(faculty_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                           _: Annotated[User, Depends(get_current_user)]):
    result = await db.execute(
        select(CourseSection).where(CourseSection.instructor_id == faculty_id)
    )
    return result.scalars().all()

@router.get("/{faculty_id}/workload")
async def faculty_workload(faculty_id: int, db: Annotated[AsyncSession, Depends(get_db)],
                           _: Annotated[User, Depends(get_current_user)]):
    count = await db.scalar(
        select(func.count()).where(CourseSection.instructor_id == faculty_id)
    )
    credit_sum = await db.scalar(
        select(func.sum(CourseSection.course.credit_hours))
        .where(CourseSection.instructor_id == faculty_id)
    )
    return {
        "faculty_id": faculty_id,
        "total_sections": count or 0,
        "total_credit_hours": credit_sum or 0,
    }
