"""Registrar router — enrollment approval, transcripts, graduation."""

from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
import os

from shared.config.database import get_db
from shared.config.settings import settings
from shared.models.orm_models import (
    Student, User, Grade, Course, CourseSection, Enrollment,
    AcademicYear, UserRole
)
from services.auth.router import get_current_user, require_roles
from shared.utils.gpa_calculator import compute_cgpa, gpa_standing
from shared.utils.pdf_generator import generate_transcript_pdf

router = APIRouter()

REGISTRAR_OR_ADMIN = require_roles(UserRole.REGISTRAR, UserRole.ADMIN)


class TranscriptRequest(BaseModel):
    student_id: str
    purpose: str = "Further Studies / ተጨማሪ ትምህርት"
    transcript_no: str | None = None


@router.get("/students")
async def list_students(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(REGISTRAR_OR_ADMIN)],
    status: str | None = Query(None),
    q: str | None = Query(None),
    skip: int = 0,
    limit: int = 50,
):
    """List all students with optional filters."""
    query = select(Student).join(User)
    if status:
        query = query.where(Student.enrollments.any())
    if q:
        query = query.where(
            (User.first_name_en.ilike(f"%{q}%")) |
            (User.last_name_en.ilike(f"%{q}%")) |
            (Student.student_id.ilike(f"%{q}%"))
        )
    result = await db.execute(query.offset(skip).limit(limit))
    return result.scalars().all()


@router.get("/students/{student_id}/transcript-data")
async def get_transcript_data(
    student_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(REGISTRAR_OR_ADMIN)],
):
    """Return structured data for transcript generation."""
    result = await db.execute(
        select(Student).where(Student.student_id == student_id)
    )
    student = result.scalar_one_or_none()
    if not student:
        raise HTTPException(status_code=404, detail=f"Student {student_id} not found")

    grade_result = await db.execute(
        select(Grade, Course, CourseSection)
        .join(CourseSection, Grade.section_id == CourseSection.id)
        .join(Course, CourseSection.course_id == Course.id)
        .where(Grade.student_id == student.id, Grade.is_finalized == True)
        .order_by(Course.id)
    )
    rows = grade_result.all()

    courses_data = [
        {
            "course_code": course.code,
            "name_en": course.name_en,
            "name_am": course.name_am,
            "section_group": course.section_group,
            "credit_hours": course.credit_hours,
            "grade_symbol": grade.grade_symbol,
            "grade_points": float(grade.grade_points or 0),
        }
        for grade, course, _ in rows
    ]

    cgpa = compute_cgpa(courses_data)
    standing_en, standing_am = gpa_standing(cgpa)

    return {
        "student_id": student.student_id,
        "name_en": f"{student.user.first_name_en} {student.user.last_name_en}",
        "name_am": f"{student.user.first_name_am or ''} {student.user.last_name_am or ''}".strip(),
        "dob_ec": student.dob_ec,
        "courses": courses_data,
        "total_courses": len(courses_data),
        "total_credits": sum(c["credit_hours"] for c in courses_data),
        "cgpa": cgpa,
        "standing_en": standing_en,
        "standing_am": standing_am,
    }


@router.post("/transcripts/generate")
async def generate_transcript(
    body: TranscriptRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(REGISTRAR_OR_ADMIN)],
):
    """Generate an official PDF transcript for a student."""
    data = await get_transcript_data(body.student_id, db, current_user)

    import uuid, datetime
    tr_no = body.transcript_no or f"DKHCBC-TR-{datetime.date.today().year}-{uuid.uuid4().hex[:6].upper()}"
    out_dir = settings.TRANSCRIPT_OUTPUT_DIR
    os.makedirs(out_dir, exist_ok=True)
    output_path = os.path.join(out_dir, f"transcript_{body.student_id}_{tr_no}.pdf")

    generate_transcript_pdf(
        student_name_en=data["name_en"],
        student_name_am=data["name_am"],
        student_id=data["student_id"],
        dob_ec=data.get("dob_ec", ""),
        courses=data["courses"],
        cgpa=data["cgpa"],
        standing_en=data["standing_en"],
        standing_am=data["standing_am"],
        transcript_no=tr_no,
        purpose=body.purpose,
        output_path=output_path,
    )

    return {
        "transcript_no": tr_no,
        "student_id": body.student_id,
        "student_name": data["name_en"],
        "cgpa": data["cgpa"],
        "standing": data["standing_en"],
        "file_path": output_path,
        "download_url": f"/api/v1/registrar/transcripts/{tr_no}/download",
    }


@router.get("/transcripts/{transcript_no}/download")
async def download_transcript(
    transcript_no: str,
    _: Annotated[User, Depends(get_current_user)],
):
    """Download a generated PDF transcript."""
    out_dir = settings.TRANSCRIPT_OUTPUT_DIR
    import glob
    matches = glob.glob(os.path.join(out_dir, f"*{transcript_no}*.pdf"))
    if not matches:
        raise HTTPException(status_code=404, detail="Transcript not found")
    return FileResponse(
        path=matches[0],
        media_type="application/pdf",
        filename=f"DKHCBC_Transcript_{transcript_no}.pdf",
    )


@router.get("/enrollment-queue")
async def get_enrollment_queue(
    db: Annotated[AsyncSession, Depends(get_db)],
    _: Annotated[User, Depends(REGISTRAR_OR_ADMIN)],
):
    result = await db.execute(
        select(Enrollment).where(Enrollment.approved_at == None).limit(50)
    )
    return result.scalars().all()


@router.patch("/enrollment-queue/{enrollment_id}/approve")
async def approve_enrollment(
    enrollment_id: int,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[User, Depends(REGISTRAR_OR_ADMIN)],
):
    result = await db.execute(select(Enrollment).where(Enrollment.id == enrollment_id))
    enrollment = result.scalar_one_or_none()
    if not enrollment:
        raise HTTPException(status_code=404, detail="Enrollment not found")

    from datetime import datetime
    enrollment.approved_by = current_user.id
    enrollment.approved_at = datetime.utcnow()
    await db.commit()
    return {"status": "approved", "enrollment_id": enrollment_id}
