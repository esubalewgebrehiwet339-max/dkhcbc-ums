"""
DKHCBC UMS — Database Seed Script
Populates the database with initial data for development and testing.
Usage: python seed.py
"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from sqlalchemy.ext.asyncio import AsyncSession
from shared.config.database import AsyncSessionLocal, create_tables
from shared.models.orm_models import (
    University, Department, Program, AcademicYear, User, UserRole,
    Faculty, Student, Course, CourseSection, Semester, Book
)
from services.auth.router import hash_password
from datetime import date


async def seed():
    await create_tables()
    async with AsyncSessionLocal() as db:
        # University
        uni = University(
            code="DKHCBC",
            name_en="Debre Kidan Holy Cross Bible College",
            name_am="ደብረ ቅዳን ቅዱስ መስቀል መጽሐፍ ቅዱስ ኮሌጅ",
            address="Debre Kidan, South Gondar Zone, Amhara Region",
            region="Amhara",
            woreda="Dera",
            phone="+251 58 222 0001",
            email="info@dkhcbc.edu.et",
        )
        db.add(uni)
        await db.flush()

        # Departments
        dept_theology = Department(university_id=uni.id, code="THEO", name_en="Theology", name_am="ሥነ-መለኮት")
        dept_ministry  = Department(university_id=uni.id, code="MIN",  name_en="Ministry Studies", name_am="የአገልግሎት ጥናት")
        dept_missions  = Department(university_id=uni.id, code="MISS", name_en="Missiology", name_am="ሚሲዮሎጂ")
        db.add_all([dept_theology, dept_ministry, dept_missions])
        await db.flush()

        # Academic Year
        ay = AcademicYear(
            label_ec="2016/17 E.C.",
            label_gc="2023/24 G.C.",
            start_date=date(2023, 9, 11),
            end_date=date(2024, 9, 10),
            is_current=True,
        )
        db.add(ay)
        await db.flush()

        # Programs
        prog_dip_theo = Program(
            department_id=dept_theology.id, code="DIP-THEO",
            name_en="Diploma in Theology", name_am="የሥነ-መለኮት ዲፕሎማ",
            degree_type="Diploma", total_credits=90, duration_years=3,
        )
        prog_bmin = Program(
            department_id=dept_ministry.id, code="BMIN",
            name_en="Bachelor of Ministry", name_am="ባቸለር ኦፍ ሚኒስትሪ",
            degree_type="Bachelor", total_credits=132, duration_years=4,
        )
        db.add_all([prog_dip_theo, prog_bmin])
        await db.flush()

        # Admin user
        admin = User(
            university_id=uni.id,
            email="admin@dkhcbc.edu.et",
            password_hash=hash_password("Admin@1234"),
            role=UserRole.ADMIN,
            first_name_en="System", last_name_en="Administrator",
            first_name_am="ሲስተም", last_name_am="አስተዳዳሪ",
        )
        registrar = User(
            university_id=uni.id,
            email="registrar@dkhcbc.edu.et",
            password_hash=hash_password("Reg@1234"),
            role=UserRole.REGISTRAR,
            first_name_en="Alemu", last_name_en="Bekele",
            first_name_am="አለሙ", last_name_am="በቀለ",
        )
        finance_user = User(
            university_id=uni.id,
            email="finance@dkhcbc.edu.et",
            password_hash=hash_password("Fin@1234"),
            role=UserRole.FINANCE,
            first_name_en="Tigist", last_name_en="Haile",
            first_name_am="ትግስት", last_name_am="ሃይሌ",
        )
        prof_user = User(
            university_id=uni.id,
            email="prof.bekele@dkhcbc.edu.et",
            password_hash=hash_password("Prof@1234"),
            role=UserRole.PROFESSOR,
            first_name_en="Rev. Yohannes", last_name_en="Bekele",
            first_name_am="ዮሃንስ", last_name_am="በቀለ",
        )
        db.add_all([admin, registrar, finance_user, prof_user])
        await db.flush()

        # Faculty
        faculty_rec = Faculty(
            user_id=prof_user.id, department_id=dept_theology.id,
            employee_id="FAC-2020-001",
            title="Rev. Dr.",
            specialization="Biblical Hermeneutics",
            qualification="PhD Theology",
            hired_date=date(2020, 9, 1),
        )
        db.add(faculty_rec)
        await db.flush()

        # Sample student user
        stu_user = User(
            university_id=uni.id,
            email="abebe.kebede@dkhcbc.edu.et",
            password_hash=hash_password("Stu@1234"),
            role=UserRole.STUDENT,
            first_name_en="Abebe", last_name_en="Kebede",
            first_name_am="አበበ", last_name_am="ከበደ",
        )
        db.add(stu_user)
        await db.flush()

        student = Student(
            user_id=stu_user.id,
            student_id="DKHCBC/001/17",
            date_of_birth=date(2000, 3, 15),
            dob_ec="07/07/1992 E.C.",
            gender="M",
            region="Amhara",
            woreda="Dera",
            sponsor_type="government",
        )
        db.add(student)

        # Courses
        courses = [
            Course(department_id=dept_theology.id, code="THEO101", name_en="Introduction to Biblical Studies", name_am="የመጽሐፍ ቅዱስ ትምህርት መግቢያ", section_group="Biblical Studies", credit_hours=3),
            Course(department_id=dept_theology.id, code="THEO201", name_en="Old Testament Survey",             name_am="የብሉይ ኪዳን ጠቅላላ እይታ",         section_group="Biblical Studies", credit_hours=3),
            Course(department_id=dept_theology.id, code="THEO202", name_en="New Testament Survey",             name_am="የአዲስ ኪዳን ጠቅላላ እይታ",          section_group="Biblical Studies", credit_hours=3),
            Course(department_id=dept_ministry.id,  code="MIN301",  name_en="Principles of Ministry",          name_am="የአገልግሎት መርሆዎች",               section_group="Ministry",        credit_hours=3),
            Course(department_id=dept_missions.id,  code="MISS201", name_en="Introduction to Missiology",      name_am="ሚሲዮሎጂ መግቢያ",                  section_group="Missions",        credit_hours=3),
        ]
        db.add_all(courses)

        # Books
        books = [
            Book(isbn="978-0-06-112008-4", title_en="The Complete Guide to Biblical Theology",
                 author="John Stott", category="Theology", total_copies=5, available=3),
            Book(isbn="978-0-310-22697-3", title_en="Systematic Theology",
                 author="Wayne Grudem", category="Theology", total_copies=8, available=2),
            Book(isbn="978-0-8254-3925-2", title_en="Amharic Bible Commentary",
                 title_am="አማርኛ የመጽሐፍ ቅዱስ ትርጓሜ",
                 author="Ethiopian Scholars", category="Reference", total_copies=10, available=7),
        ]
        db.add_all(books)

        await db.commit()
        print("✅ Seed complete!")
        print(f"   Admin:     admin@dkhcbc.edu.et    / Admin@1234")
        print(f"   Registrar: registrar@dkhcbc.edu.et / Reg@1234")
        print(f"   Finance:   finance@dkhcbc.edu.et   / Fin@1234")
        print(f"   Professor: prof.bekele@dkhcbc.edu.et / Prof@1234")
        print(f"   Student:   abebe.kebede@dkhcbc.edu.et / Stu@1234")


if __name__ == "__main__":
    asyncio.run(seed())
