"""
PDF Transcript Generator — DKHCBC UMS
Produces bilingual (English + Amharic) official transcripts using ReportLab.
Requires a TTF font with Ethiopic Unicode support (e.g. Noto Sans Ethiopic).
"""

from __future__ import annotations
import os
from datetime import date
from typing import List

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph,
    Spacer, HRFlowable,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ── Font Registration ─────────────────────────────────────────────────────────
_FONT_DIRS = [
    "/usr/share/fonts/truetype/noto",
    "/usr/share/fonts/truetype/freefont",
    "/usr/local/share/fonts",
    os.path.join(os.path.dirname(__file__), "fonts"),
]

def _register_amharic_font() -> str:
    """Try to register an Ethiopic-capable TTF. Returns font name or fallback."""
    candidates = [
        ("NotoSansEthiopic", "NotoSansEthiopic-Regular.ttf"),
        ("FreeSerif",        "FreeSerif.ttf"),
        ("FreeSans",         "FreeSans.ttf"),
    ]
    for font_name, filename in candidates:
        for d in _FONT_DIRS:
            path = os.path.join(d, filename)
            if os.path.exists(path):
                try:
                    pdfmetrics.registerFont(TTFont(font_name, path))
                    return font_name
                except Exception:
                    continue
    return "Helvetica"  # ASCII-only fallback


AMHARIC_FONT = _register_amharic_font()

# ── Color Palette ─────────────────────────────────────────────────────────────
NAVY   = colors.HexColor("#1A2B5C")
GOLD   = colors.HexColor("#C9952A")
LIGHT  = colors.HexColor("#F4F6FB")
GREY   = colors.HexColor("#6B7280")
WHITE  = colors.white
BLACK  = colors.black


def generate_transcript_pdf(
    student_name_en: str,
    student_name_am: str,
    student_id: str,
    dob_ec: str,
    courses: List[dict],
    cgpa: float,
    standing_en: str,
    standing_am: str,
    transcript_no: str,
    purpose: str,
    output_path: str,
) -> str:
    """Generate an official PDF transcript and save to output_path."""

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2*cm,  bottomMargin=2*cm,
    )

    story = []
    W = A4[0] - 4*cm  # usable width

    # ── Header ────────────────────────────────────────────────────────────────
    header_data = [[
        Paragraph(
            f"<font size='14' color='#1A2B5C'><b>DEBRE KIDAN HOLY CROSS BIBLE COLLEGE</b></font><br/>"
            f"<font size='10' color='#6B7280'>Accredited Theological Institution · Ethiopia</font>",
            ParagraphStyle("h", fontName=AMHARIC_FONT, leading=16)
        ),
        Paragraph(
            f"<font size='10' color='#1A2B5C'><b>OFFICIAL TRANSCRIPT</b></font><br/>"
            f"<font size='8' color='#6B7280'>No: {transcript_no}</font><br/>"
            f"<font size='8' color='#6B7280'>Date: {date.today()}</font>",
            ParagraphStyle("h2", fontName=AMHARIC_FONT, leading=14, alignment=2)
        ),
    ]]
    header_tbl = Table(header_data, colWidths=[W * 0.65, W * 0.35])
    header_tbl.setStyle(TableStyle([
        ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(header_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=NAVY, spaceAfter=8))

    # ── Student Information ───────────────────────────────────────────────────
    info_style = ParagraphStyle("info", fontName=AMHARIC_FONT, fontSize=9, leading=14)
    info_data = [
        ["Student Name (EN):", student_name_en,  "Student ID:",     student_id],
        ["Student Name (AM):", student_name_am,  "Date of Birth (E.C.):", dob_ec or "N/A"],
        ["Purpose:",           purpose,          "Academic Year:",  "2016/17 E.C."],
    ]
    info_tbl = Table(info_data, colWidths=[W*0.20, W*0.30, W*0.20, W*0.30])
    info_tbl.setStyle(TableStyle([
        ("FONTNAME",   (0, 0), (-1, -1), AMHARIC_FONT),
        ("FONTSIZE",   (0, 0), (-1, -1), 9),
        ("FONTNAME",   (0, 0), (0, -1), AMHARIC_FONT),
        ("FONTSIZE",   (0, 0), (0, -1), 9),
        ("TEXTCOLOR",  (0, 0), (0, -1), GREY),
        ("TEXTCOLOR",  (2, 0), (2, -1), GREY),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [LIGHT, WHITE]),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("LEFTPADDING",   (0, 0), (-1, -1), 6),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1, 12))

    # ── Courses Table ─────────────────────────────────────────────────────────
    story.append(Paragraph(
        "<b>Academic Record / የትምህርት መዝገብ</b>",
        ParagraphStyle("sec", fontName=AMHARIC_FONT, fontSize=10, textColor=NAVY, spaceAfter=6)
    ))

    col_headers = ["Code", "Course Name (EN)", "Course Name (AM)", "Cr. Hrs", "Grade", "Points"]
    rows = [col_headers]
    for c in courses:
        rows.append([
            c.get("course_code", ""),
            c.get("name_en", ""),
            c.get("name_am", "") or "",
            str(c.get("credit_hours", 0)),
            str(c.get("grade_symbol", "")),
            f"{c.get('grade_points', 0):.1f}",
        ])

    col_w = [W*0.10, W*0.27, W*0.27, W*0.09, W*0.12, W*0.15]
    courses_tbl = Table(rows, colWidths=col_w, repeatRows=1)
    courses_tbl.setStyle(TableStyle([
        ("FONTNAME",       (0, 0), (-1, -1), AMHARIC_FONT),
        ("FONTSIZE",       (0, 0), (-1, -1), 8),
        ("BACKGROUND",     (0, 0), (-1, 0),  NAVY),
        ("TEXTCOLOR",      (0, 0), (-1, 0),  WHITE),
        ("FONTSIZE",       (0, 0), (-1, 0),  9),
        ("ALIGN",          (3, 0), (-1, -1), "CENTER"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT]),
        ("GRID",           (0, 0), (-1, -1), 0.5, colors.HexColor("#D1D5DB")),
        ("TOPPADDING",     (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING",  (0, 0), (-1, -1), 5),
        ("LEFTPADDING",    (0, 0), (-1, -1), 5),
    ]))
    story.append(courses_tbl)
    story.append(Spacer(1, 12))

    # ── Summary ───────────────────────────────────────────────────────────────
    total_credits = sum(c.get("credit_hours", 0) for c in courses)
    summary_data = [
        ["Total Courses:", str(len(courses)),
         "Total Credits:", str(total_credits),
         "CGPA:", f"{cgpa:.2f}",
         "Standing:", f"{standing_en} / {standing_am}"],
    ]
    summary_tbl = Table(summary_data, colWidths=[W*0.13]*8)
    summary_tbl.setStyle(TableStyle([
        ("FONTNAME",  (0, 0), (-1, -1), AMHARIC_FONT),
        ("FONTSIZE",  (0, 0), (-1, -1), 9),
        ("BACKGROUND",(0, 0), (-1, -1), LIGHT),
        ("TEXTCOLOR", (0, 0), (0, 0),   GREY),
        ("TEXTCOLOR", (2, 0), (2, 0),   GREY),
        ("TEXTCOLOR", (4, 0), (4, 0),   GREY),
        ("TEXTCOLOR", (6, 0), (6, 0),   GREY),
        ("FONTNAME",  (1, 0), (1, 0),   AMHARIC_FONT),
        ("FONTSIZE",  (1, 0), (1, 0),   10),
        ("TEXTCOLOR", (5, 0), (5, 0),   NAVY),
        ("FONTSIZE",  (5, 0), (5, 0),   12),
        ("GRID",      (0, 0), (-1, -1), 0.5, colors.HexColor("#D1D5DB")),
        ("ALIGN",     (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(summary_tbl)
    story.append(Spacer(1, 24))

    # ── Signatures ────────────────────────────────────────────────────────────
    sig_data = [
        ["_________________________", "   ", "_________________________"],
        ["Registrar Signature",       "   ", "Academic Dean Signature"],
        ["ሬጂስትራር ፊርማ",              "   ", "የአካዳሚክ ዲን ፊርማ"],
    ]
    sig_tbl = Table(sig_data, colWidths=[W*0.40, W*0.20, W*0.40])
    sig_tbl.setStyle(TableStyle([
        ("FONTNAME",  (0, 0), (-1, -1), AMHARIC_FONT),
        ("FONTSIZE",  (0, 0), (-1, -1), 9),
        ("ALIGN",     (0, 0), (-1, -1), "CENTER"),
        ("TEXTCOLOR", (0, 1), (-1, -1), GREY),
    ]))
    story.append(sig_tbl)

    story.append(Spacer(1, 12))
    story.append(HRFlowable(width="100%", thickness=1, color=GOLD, spaceAfter=6))
    story.append(Paragraph(
        "<font size='7' color='#6B7280'>This is an official document of Debre Kidan Holy Cross Bible College. "
        "Any alteration renders it invalid. Issued under seal of the Registrar's Office.</font>",
        ParagraphStyle("footer", fontName=AMHARIC_FONT, fontSize=7, textColor=GREY, alignment=1)
    ))

    doc.build(story)
    return output_path
