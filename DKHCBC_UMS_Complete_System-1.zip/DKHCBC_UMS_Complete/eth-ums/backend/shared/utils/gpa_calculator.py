"""
DKHCBC Ethiopian University Grading System
CA (Continuous Assessment): 30%
Mid-term:                    30%
Final Exam:                  40%
"""
from typing import Tuple


GRADE_TABLE = [
    (90, "A+", 4.0),
    (85, "A",  4.0),
    (80, "A-", 3.7),
    (75, "B+", 3.3),
    (70, "B",  3.0),
    (65, "B-", 2.7),
    (60, "C+", 2.3),
    (55, "C",  2.0),
    (0,  "F",  0.0),
]


def score_to_grade(total_score: float) -> Tuple[str, float]:
    """Convert a numeric score (0–100) to (grade_symbol, grade_points)."""
    for threshold, symbol, points in GRADE_TABLE:
        if total_score >= threshold:
            return symbol, points
    return "F", 0.0


def compute_cgpa(courses: list[dict]) -> float:
    """
    Compute CGPA from a list of dicts with keys:
        credit_hours (int), grade_points (float)
    Returns rounded CGPA to 2 decimal places.
    """
    total_credits = sum(c["credit_hours"] for c in courses if c.get("grade_points", 0) > 0)
    weighted_sum  = sum(c["credit_hours"] * c["grade_points"] for c in courses)
    if total_credits == 0:
        return 0.0
    return round(weighted_sum / total_credits, 2)


def gpa_standing(cgpa: float) -> Tuple[str, str]:
    """Return (English standing, Amharic standing) for a CGPA value."""
    if cgpa >= 3.75:
        return "Summa Cum Laude",   "ሱማ ከም ላውዴ"
    if cgpa >= 3.50:
        return "Magna Cum Laude",   "ማግና ከም ላውዴ"
    if cgpa >= 3.25:
        return "Cum Laude",         "ከም ላውዴ"
    if cgpa >= 2.00:
        return "Satisfactory",      "አጥጋቢ"
    if cgpa >= 1.00:
        return "Academic Probation","ከዩኒቨርሲቲ ክትትል ስር"
    return "Unsatisfactory",        "ተቀባይነት የሌለው"
