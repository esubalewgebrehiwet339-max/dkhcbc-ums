"""
DKHCBC UMS — SQLAlchemy ORM Models
All database tables for the University Management System.
Supports bilingual fields (English + Amharic / name_am columns).
"""

from __future__ import annotations
from datetime import datetime, date
from decimal import Decimal
from typing import Optional, List
from enum import Enum as PyEnum

from sqlalchemy import (
    String, Integer, Numeric, Boolean, DateTime, Date, Text,
    ForeignKey, Enum, UniqueConstraint, Index, func
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from shared.config.database import Base


# ── Enums ─────────────────────────────────────────────────────────────────────

class UserRole(str, PyEnum):
    ADMIN        = "admin"
    REGISTRAR    = "registrar"
    FINANCE      = "finance"
    DEPARTMENT_HEAD = "department_head"
    PROFESSOR    = "professor"
    LIBRARIAN    = "librarian"
    STUDENT      = "student"

class EnrollmentStatus(str, PyEnum):
    ACTIVE     = "active"
    WITHDRAWN  = "withdrawn"
    GRADUATED  = "graduated"
    SUSPENDED  = "suspended"
    PROBATION  = "probation"

class PaymentStatus(str, PyEnum):
    PAID       = "paid"
    PARTIAL    = "partial"
    OVERDUE    = "overdue"
    WAIVED     = "waived"

class Semester(str, PyEnum):
    SEMESTER_I  = "semester_i"
    SEMESTER_II = "semester_ii"
    SUMMER      = "summer"

class GradeSymbol(str, PyEnum):
    A_PLUS = "A+"
    A      = "A"
    A_MINUS = "A-"
    B_PLUS = "B+"
    B      = "B"
    B_MINUS = "B-"
    C_PLUS = "C+"
    C      = "C"
    F      = "F"
    I      = "I"   # Incomplete
    W      = "W"   # Withdrawn

class LoanStatus(str, PyEnum):
    BORROWED = "borrowed"
    RETURNED = "returned"
    OVERDUE  = "overdue"
    LOST     = "lost"

class SponsorType(str, PyEnum):
    GOVERNMENT = "government"
    PRIVATE    = "private"
    NGO        = "ngo"
    SELF       = "self"


# ── Mixins ────────────────────────────────────────────────────────────────────

class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(),
        onupdate=func.now(), nullable=False
    )


# ── Core Tables ───────────────────────────────────────────────────────────────

class University(Base, TimestampMixin):
    __tablename__ = "universities"

    id:          Mapped[int]  = mapped_column(Integer, primary_key=True)
    code:        Mapped[str]  = mapped_column(String(20), unique=True, nullable=False)
    name_en:     Mapped[str]  = mapped_column(String(200), nullable=False)
    name_am:     Mapped[Optional[str]] = mapped_column(String(200))
    address:     Mapped[Optional[str]] = mapped_column(Text)
    region:      Mapped[Optional[str]] = mapped_column(String(100))
    woreda:      Mapped[Optional[str]] = mapped_column(String(100))
    kebele:      Mapped[Optional[str]] = mapped_column(String(100))
    phone:       Mapped[Optional[str]] = mapped_column(String(30))
    email:       Mapped[Optional[str]] = mapped_column(String(100))
    website:     Mapped[Optional[str]] = mapped_column(String(200))
    is_active:   Mapped[bool] = mapped_column(Boolean, default=True)

    departments: Mapped[List["Department"]] = relationship(back_populates="university")
    users:       Mapped[List["User"]]       = relationship(back_populates="university")


class Department(Base, TimestampMixin):
    __tablename__ = "departments"

    id:             Mapped[int]  = mapped_column(Integer, primary_key=True)
    university_id:  Mapped[int]  = mapped_column(ForeignKey("universities.id"), nullable=False)
    code:           Mapped[str]  = mapped_column(String(20), nullable=False)
    name_en:        Mapped[str]  = mapped_column(String(200), nullable=False)
    name_am:        Mapped[Optional[str]] = mapped_column(String(200))
    description:    Mapped[Optional[str]] = mapped_column(Text)
    head_id:        Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    is_active:      Mapped[bool] = mapped_column(Boolean, default=True)

    university:  Mapped["University"]  = relationship(back_populates="departments")
    head:        Mapped[Optional["User"]] = relationship(foreign_keys=[head_id])
    programs:    Mapped[List["Program"]]  = relationship(back_populates="department")
    courses:     Mapped[List["Course"]]   = relationship(back_populates="department")

    __table_args__ = (UniqueConstraint("university_id", "code"),)


class Program(Base, TimestampMixin):
    __tablename__ = "programs"

    id:            Mapped[int]  = mapped_column(Integer, primary_key=True)
    department_id: Mapped[int]  = mapped_column(ForeignKey("departments.id"), nullable=False)
    code:          Mapped[str]  = mapped_column(String(30), unique=True, nullable=False)
    name_en:       Mapped[str]  = mapped_column(String(200), nullable=False)
    name_am:       Mapped[Optional[str]] = mapped_column(String(200))
    degree_type:   Mapped[str]  = mapped_column(String(50), default="Diploma")
    total_credits: Mapped[int]  = mapped_column(Integer, default=90)
    duration_years:Mapped[int]  = mapped_column(Integer, default=2)
    is_active:     Mapped[bool] = mapped_column(Boolean, default=True)

    department:  Mapped["Department"]      = relationship(back_populates="programs")
    enrollments: Mapped[List["Enrollment"]]= relationship(back_populates="program")


class AcademicYear(Base):
    __tablename__ = "academic_years"

    id:         Mapped[int]  = mapped_column(Integer, primary_key=True)
    label_ec:   Mapped[str]  = mapped_column(String(20), unique=True, nullable=False)  # "2016/17 E.C."
    label_gc:   Mapped[str]  = mapped_column(String(20))                               # "2023/24 G.C."
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date:   Mapped[date] = mapped_column(Date, nullable=False)
    is_current: Mapped[bool] = mapped_column(Boolean, default=False)

    sections:   Mapped[List["CourseSection"]] = relationship(back_populates="academic_year")


# ── Users ─────────────────────────────────────────────────────────────────────

class User(Base, TimestampMixin):
    __tablename__ = "users"

    id:            Mapped[int]  = mapped_column(Integer, primary_key=True)
    university_id: Mapped[int]  = mapped_column(ForeignKey("universities.id"), nullable=False)
    email:         Mapped[str]  = mapped_column(String(150), unique=True, nullable=False)
    password_hash: Mapped[str]  = mapped_column(String(255), nullable=False)
    role:          Mapped[UserRole] = mapped_column(Enum(UserRole), nullable=False)
    first_name_en: Mapped[str]  = mapped_column(String(100), nullable=False)
    last_name_en:  Mapped[str]  = mapped_column(String(100), nullable=False)
    first_name_am: Mapped[Optional[str]] = mapped_column(String(100))
    last_name_am:  Mapped[Optional[str]] = mapped_column(String(100))
    phone:         Mapped[Optional[str]] = mapped_column(String(30))
    is_active:     Mapped[bool] = mapped_column(Boolean, default=True)
    last_login:    Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    university:  Mapped["University"]       = relationship(back_populates="users")
    student:     Mapped[Optional["Student"]]= relationship(back_populates="user", uselist=False)
    faculty:     Mapped[Optional["Faculty"]]= relationship(back_populates="user", uselist=False)

    __table_args__ = (Index("ix_users_email", "email"),)


# ── Students ──────────────────────────────────────────────────────────────────

class Student(Base, TimestampMixin):
    __tablename__ = "students"

    id:              Mapped[int]  = mapped_column(Integer, primary_key=True)
    user_id:         Mapped[int]  = mapped_column(ForeignKey("users.id"), unique=True)
    student_id:      Mapped[str]  = mapped_column(String(30), unique=True, nullable=False)
    date_of_birth:   Mapped[Optional[date]] = mapped_column(Date)
    dob_ec:          Mapped[Optional[str]]  = mapped_column(String(30))  # Ethiopian Calendar
    gender:          Mapped[Optional[str]]  = mapped_column(String(10))
    region:          Mapped[Optional[str]]  = mapped_column(String(100))
    woreda:          Mapped[Optional[str]]  = mapped_column(String(100))
    kebele:          Mapped[Optional[str]]  = mapped_column(String(100))
    sponsor_type:    Mapped[SponsorType]    = mapped_column(Enum(SponsorType), default=SponsorType.SELF)
    emergency_name:  Mapped[Optional[str]]  = mapped_column(String(200))
    emergency_phone: Mapped[Optional[str]]  = mapped_column(String(30))

    user:         Mapped["User"]             = relationship(back_populates="student")
    enrollments:  Mapped[List["Enrollment"]] = relationship(back_populates="student")
    fee_records:  Mapped[List["FeeRecord"]]  = relationship(back_populates="student")
    loans:        Mapped[List["LibraryLoan"]]= relationship(back_populates="student")

    __table_args__ = (Index("ix_students_student_id", "student_id"),)


# ── Faculty ───────────────────────────────────────────────────────────────────

class Faculty(Base, TimestampMixin):
    __tablename__ = "faculty"

    id:             Mapped[int]  = mapped_column(Integer, primary_key=True)
    user_id:        Mapped[int]  = mapped_column(ForeignKey("users.id"), unique=True)
    department_id:  Mapped[int]  = mapped_column(ForeignKey("departments.id"))
    employee_id:    Mapped[str]  = mapped_column(String(30), unique=True, nullable=False)
    title:          Mapped[Optional[str]] = mapped_column(String(50))   # Rev., Dr., Prof.
    specialization: Mapped[Optional[str]] = mapped_column(String(200))
    qualification:  Mapped[Optional[str]] = mapped_column(String(200))
    hired_date:     Mapped[Optional[date]]= mapped_column(Date)
    is_active:      Mapped[bool] = mapped_column(Boolean, default=True)

    user:       Mapped["User"]                  = relationship(back_populates="faculty")
    department: Mapped["Department"]            = relationship()
    sections:   Mapped[List["CourseSection"]]   = relationship(back_populates="instructor")


# ── Courses & Sections ────────────────────────────────────────────────────────

class Course(Base, TimestampMixin):
    __tablename__ = "courses"

    id:            Mapped[int]  = mapped_column(Integer, primary_key=True)
    department_id: Mapped[int]  = mapped_column(ForeignKey("departments.id"))
    code:          Mapped[str]  = mapped_column(String(20), unique=True, nullable=False)
    name_en:       Mapped[str]  = mapped_column(String(300), nullable=False)
    name_am:       Mapped[Optional[str]] = mapped_column(String(300))
    section_group: Mapped[Optional[str]] = mapped_column(String(100))  # "Biblical Studies" etc.
    credit_hours:  Mapped[int]  = mapped_column(Integer, default=3)
    description:   Mapped[Optional[str]] = mapped_column(Text)
    is_active:     Mapped[bool] = mapped_column(Boolean, default=True)

    department: Mapped["Department"]           = relationship(back_populates="courses")
    sections:   Mapped[List["CourseSection"]]  = relationship(back_populates="course")


class CourseSection(Base, TimestampMixin):
    __tablename__ = "course_sections"

    id:               Mapped[int]  = mapped_column(Integer, primary_key=True)
    course_id:        Mapped[int]  = mapped_column(ForeignKey("courses.id"))
    instructor_id:    Mapped[Optional[int]] = mapped_column(ForeignKey("faculty.id"))
    academic_year_id: Mapped[int]  = mapped_column(ForeignKey("academic_years.id"))
    semester:         Mapped[Semester] = mapped_column(Enum(Semester))
    section_code:     Mapped[str]  = mapped_column(String(10), default="A")
    max_students:     Mapped[int]  = mapped_column(Integer, default=30)
    room:             Mapped[Optional[str]] = mapped_column(String(50))
    schedule:         Mapped[Optional[str]] = mapped_column(String(200))

    course:        Mapped["Course"]              = relationship(back_populates="sections")
    instructor:    Mapped[Optional["Faculty"]]   = relationship(back_populates="sections")
    academic_year: Mapped["AcademicYear"]        = relationship(back_populates="sections")
    enrollments:   Mapped[List["Enrollment"]]    = relationship(back_populates="section")
    grades:        Mapped[List["Grade"]]         = relationship(back_populates="section")


# ── Enrollment & Grades ───────────────────────────────────────────────────────

class Enrollment(Base, TimestampMixin):
    __tablename__ = "enrollments"

    id:         Mapped[int]  = mapped_column(Integer, primary_key=True)
    student_id: Mapped[int]  = mapped_column(ForeignKey("students.id"))
    section_id: Mapped[int]  = mapped_column(ForeignKey("course_sections.id"))
    program_id: Mapped[int]  = mapped_column(ForeignKey("programs.id"))
    status:     Mapped[EnrollmentStatus] = mapped_column(
        Enum(EnrollmentStatus), default=EnrollmentStatus.ACTIVE
    )
    enrolled_at:  Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    approved_by:  Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    approved_at:  Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    student: Mapped["Student"]       = relationship(back_populates="enrollments")
    section: Mapped["CourseSection"] = relationship(back_populates="enrollments")
    program: Mapped["Program"]       = relationship(back_populates="enrollments")

    __table_args__ = (UniqueConstraint("student_id", "section_id"),)


class Grade(Base, TimestampMixin):
    __tablename__ = "grades"

    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    student_id:   Mapped[int]  = mapped_column(ForeignKey("students.id"))
    section_id:   Mapped[int]  = mapped_column(ForeignKey("course_sections.id"))
    ca_score:     Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))   # 30%
    mid_score:    Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))   # 30%
    final_score:  Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))   # 40%
    total_score:  Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    grade_symbol: Mapped[Optional[GradeSymbol]] = mapped_column(Enum(GradeSymbol))
    grade_points: Mapped[Optional[Decimal]] = mapped_column(Numeric(4, 2))
    is_finalized: Mapped[bool] = mapped_column(Boolean, default=False)
    submitted_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))

    student: Mapped["Student"]       = relationship()
    section: Mapped["CourseSection"] = relationship(back_populates="grades")

    __table_args__ = (UniqueConstraint("student_id", "section_id"),)


# ── Finance ───────────────────────────────────────────────────────────────────

class FeeStructure(Base, TimestampMixin):
    __tablename__ = "fee_structures"

    id:               Mapped[int]     = mapped_column(Integer, primary_key=True)
    program_id:       Mapped[int]     = mapped_column(ForeignKey("programs.id"))
    academic_year_id: Mapped[int]     = mapped_column(ForeignKey("academic_years.id"))
    tuition_etb:      Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    registration_etb: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0)
    other_fees_etb:   Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0)
    description:      Mapped[Optional[str]] = mapped_column(Text)


class FeeRecord(Base, TimestampMixin):
    __tablename__ = "fee_records"

    id:              Mapped[int]     = mapped_column(Integer, primary_key=True)
    student_id:      Mapped[int]     = mapped_column(ForeignKey("students.id"))
    fee_structure_id:Mapped[int]     = mapped_column(ForeignKey("fee_structures.id"))
    total_due_etb:   Mapped[Decimal] = mapped_column(Numeric(10, 2))
    paid_etb:        Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0)
    status:          Mapped[PaymentStatus] = mapped_column(Enum(PaymentStatus), default=PaymentStatus.OVERDUE)
    due_date:        Mapped[Optional[date]] = mapped_column(Date)

    student:   Mapped["Student"]        = relationship(back_populates="fee_records")
    payments:  Mapped[List["Payment"]]  = relationship(back_populates="fee_record")


class Payment(Base, TimestampMixin):
    __tablename__ = "payments"

    id:             Mapped[int]     = mapped_column(Integer, primary_key=True)
    fee_record_id:  Mapped[int]     = mapped_column(ForeignKey("fee_records.id"))
    amount_etb:     Mapped[Decimal] = mapped_column(Numeric(10, 2))
    payment_date:   Mapped[date]    = mapped_column(Date, nullable=False)
    receipt_no:     Mapped[Optional[str]] = mapped_column(String(50))
    method:         Mapped[str]     = mapped_column(String(50), default="cash")
    recorded_by:    Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    notes:          Mapped[Optional[str]] = mapped_column(Text)

    fee_record: Mapped["FeeRecord"] = relationship(back_populates="payments")


class Scholarship(Base, TimestampMixin):
    __tablename__ = "scholarships"

    id:          Mapped[int]     = mapped_column(Integer, primary_key=True)
    student_id:  Mapped[int]     = mapped_column(ForeignKey("students.id"))
    name_en:     Mapped[str]     = mapped_column(String(200))
    name_am:     Mapped[Optional[str]] = mapped_column(String(200))
    amount_etb:  Mapped[Decimal] = mapped_column(Numeric(10, 2))
    academic_year_id: Mapped[int]= mapped_column(ForeignKey("academic_years.id"))
    is_active:   Mapped[bool]    = mapped_column(Boolean, default=True)
    notes:       Mapped[Optional[str]] = mapped_column(Text)


# ── Library ───────────────────────────────────────────────────────────────────

class Book(Base, TimestampMixin):
    __tablename__ = "books"

    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    isbn:         Mapped[Optional[str]] = mapped_column(String(20), unique=True)
    title_en:     Mapped[str]  = mapped_column(String(400), nullable=False)
    title_am:     Mapped[Optional[str]] = mapped_column(String(400))
    author:       Mapped[str]  = mapped_column(String(300), nullable=False)
    publisher:    Mapped[Optional[str]] = mapped_column(String(200))
    year:         Mapped[Optional[int]] = mapped_column(Integer)
    category:     Mapped[Optional[str]] = mapped_column(String(100))
    total_copies: Mapped[int]  = mapped_column(Integer, default=1)
    available:    Mapped[int]  = mapped_column(Integer, default=1)
    is_active:    Mapped[bool] = mapped_column(Boolean, default=True)

    loans: Mapped[List["LibraryLoan"]] = relationship(back_populates="book")


class LibraryLoan(Base, TimestampMixin):
    __tablename__ = "library_loans"

    id:           Mapped[int]  = mapped_column(Integer, primary_key=True)
    book_id:      Mapped[int]  = mapped_column(ForeignKey("books.id"))
    student_id:   Mapped[int]  = mapped_column(ForeignKey("students.id"))
    issued_at:    Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    due_date:     Mapped[date] = mapped_column(Date, nullable=False)
    returned_at:  Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    status:       Mapped[LoanStatus] = mapped_column(Enum(LoanStatus), default=LoanStatus.BORROWED)
    fine_etb:     Mapped[Decimal] = mapped_column(Numeric(8, 2), default=0)
    fine_paid:    Mapped[bool]    = mapped_column(Boolean, default=False)
    issued_by:    Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))

    book:    Mapped["Book"]    = relationship(back_populates="loans")
    student: Mapped["Student"] = relationship(back_populates="loans")


# ── Notifications ─────────────────────────────────────────────────────────────

class Notification(Base, TimestampMixin):
    __tablename__ = "notifications"

    id:          Mapped[int]  = mapped_column(Integer, primary_key=True)
    user_id:     Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))  # null = broadcast
    title:       Mapped[str]  = mapped_column(String(300), nullable=False)
    title_am:    Mapped[Optional[str]] = mapped_column(String(300))
    message:     Mapped[str]  = mapped_column(Text, nullable=False)
    message_am:  Mapped[Optional[str]] = mapped_column(Text)
    type:        Mapped[str]  = mapped_column(String(50), default="info")
    is_read:     Mapped[bool] = mapped_column(Boolean, default=False)
    sent_by:     Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))


# ── Audit Log ─────────────────────────────────────────────────────────────────

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id:         Mapped[int]  = mapped_column(Integer, primary_key=True)
    user_id:    Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    action:     Mapped[str]  = mapped_column(String(100), nullable=False)
    resource:   Mapped[str]  = mapped_column(String(100), nullable=False)
    resource_id:Mapped[Optional[str]] = mapped_column(String(50))
    details:    Mapped[Optional[str]] = mapped_column(Text)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45))
    user_agent: Mapped[Optional[str]] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (Index("ix_audit_logs_user_id", "user_id"),
                      Index("ix_audit_logs_created_at", "created_at"),)
