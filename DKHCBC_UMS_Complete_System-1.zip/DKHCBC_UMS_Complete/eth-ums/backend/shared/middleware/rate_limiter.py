"""Rate limiting middleware using Redis sliding window."""

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
import time

from shared.config.settings import settings


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting on health check and docs
        if request.url.path in ("/health", "/api/docs", "/api/redoc", "/api/openapi.json"):
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        key = f"rate_limit:{client_ip}"

        try:
            from shared.config.redis_client import get_redis
            redis = await get_redis()
            now = int(time.time())
            window = settings.RATE_LIMIT_WINDOW_SECONDS
            max_requests = settings.RATE_LIMIT_REQUESTS

            # Sliding window counter
            pipe = redis.pipeline()
            pipe.zremrangebyscore(key, 0, now - window)
            pipe.zadd(key, {str(now): now})
            pipe.zcard(key)
            pipe.expire(key, window)
            results = await pipe.execute()
            request_count = results[2]

            if request_count > max_requests:
                return JSONResponse(
                    status_code=429,
                    content={
                        "detail": "Rate limit exceeded. Please slow down.",
                        "retry_after": window,
                    },
                    headers={"Retry-After": str(window)},
                )
        except Exception:
            # If Redis is unavailable, allow the request through
            pass

        response = await call_next(request)
        return response
