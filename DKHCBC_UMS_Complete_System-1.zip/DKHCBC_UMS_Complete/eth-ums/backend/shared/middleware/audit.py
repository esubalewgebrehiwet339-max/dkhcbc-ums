"""Audit log middleware — records all mutating API calls."""

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from jose import jwt, JWTError
from shared.config.settings import settings


class AuditMiddleware(BaseHTTPMiddleware):
    MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)

        if request.method not in self.MUTATING_METHODS:
            return response

        # Extract user_id from JWT if present
        user_id = None
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            try:
                payload = jwt.decode(
                    auth[7:], settings.JWT_SECRET_KEY,
                    algorithms=[settings.JWT_ALGORITHM]
                )
                user_id = int(payload.get("sub", 0)) or None
            except (JWTError, ValueError):
                pass

        # Fire-and-forget audit log write
        try:
            from shared.config.database import AsyncSessionLocal
            from shared.models.orm_models import AuditLog

            path_parts = request.url.path.strip("/").split("/")
            resource = path_parts[2] if len(path_parts) > 2 else "unknown"
            resource_id = path_parts[3] if len(path_parts) > 3 else None

            async with AsyncSessionLocal() as db:
                log = AuditLog(
                    user_id=user_id,
                    action=request.method,
                    resource=resource,
                    resource_id=resource_id,
                    ip_address=request.client.host if request.client else None,
                    user_agent=request.headers.get("User-Agent", "")[:500],
                )
                db.add(log)
                await db.commit()
        except Exception:
            pass  # Never let audit failures break the request

        return response
