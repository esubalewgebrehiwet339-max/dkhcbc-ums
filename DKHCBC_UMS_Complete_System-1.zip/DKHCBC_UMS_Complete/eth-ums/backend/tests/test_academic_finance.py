"""Tests for Academic and Finance services."""

import pytest
from httpx import AsyncClient


# ── GPA Calculator Unit Tests ─────────────────────────────────────────────────

def test_score_to_grade_a_plus():
    from shared.utils.gpa_calculator import score_to_grade
    symbol, points = score_to_grade(95)
    assert symbol == "A+"
    assert points == 4.0


def test_score_to_grade_b():
    from shared.utils.gpa_calculator import score_to_grade
    symbol, points = score_to_grade(72)
    assert symbol == "B"
    assert points == 3.0


def test_score_to_grade_fail():
    from shared.utils.gpa_calculator import score_to_grade
    symbol, points = score_to_grade(40)
    assert symbol == "F"
    assert points == 0.0


def test_compute_cgpa_perfect():
    from shared.utils.gpa_calculator import compute_cgpa
    courses = [
        {"credit_hours": 3, "grade_points": 4.0},
        {"credit_hours": 3, "grade_points": 4.0},
        {"credit_hours": 3, "grade_points": 4.0},
    ]
    assert compute_cgpa(courses) == 4.0


def test_compute_cgpa_mixed():
    from shared.utils.gpa_calculator import compute_cgpa
    courses = [
        {"credit_hours": 3, "grade_points": 4.0},  # A
        {"credit_hours": 3, "grade_points": 3.0},  # B
        {"credit_hours": 3, "grade_points": 2.0},  # C
    ]
    # (12 + 9 + 6) / 9 = 3.0
    assert compute_cgpa(courses) == 3.0


def test_compute_cgpa_weighted():
    from shared.utils.gpa_calculator import compute_cgpa
    courses = [
        {"credit_hours": 4, "grade_points": 4.0},
        {"credit_hours": 2, "grade_points": 2.0},
    ]
    # (16 + 4) / 6 = 3.33
    assert compute_cgpa(courses) == 3.33


def test_gpa_standing_summa():
    from shared.utils.gpa_calculator import gpa_standing
    en, am = gpa_standing(3.90)
    assert "Summa" in en


def test_gpa_standing_probation():
    from shared.utils.gpa_calculator import gpa_standing
    en, am = gpa_standing(1.50)
    assert "Probation" in en


def test_compute_cgpa_empty():
    from shared.utils.gpa_calculator import compute_cgpa
    assert compute_cgpa([]) == 0.0


# ── API Tests ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_courses_unauthenticated(client: AsyncClient):
    response = await client.get("/api/v1/academic/courses")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_list_courses_authenticated(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/academic/courses",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_list_programs(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/academic/programs",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200


@pytest.mark.asyncio
async def test_finance_summary(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/finance/summary",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "total_due_etb" in data
    assert "collection_rate_pct" in data
    assert data["currency"] == "ETB"


@pytest.mark.asyncio
async def test_analytics_dashboard(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/analytics/dashboard",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "students" in data
    assert "finance" in data
    assert "library" in data


@pytest.mark.asyncio
async def test_list_students_requires_auth(client: AsyncClient):
    response = await client.get("/api/v1/students")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_list_fee_structures(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/finance/fee-structures",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
