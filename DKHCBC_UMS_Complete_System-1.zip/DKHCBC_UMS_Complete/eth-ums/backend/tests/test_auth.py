"""Tests for Authentication service."""

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_health_check(client: AsyncClient):
    response = await client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data


@pytest.mark.asyncio
async def test_login_invalid_credentials(client: AsyncClient):
    response = await client.post("/api/v1/auth/login", json={
        "email": "nobody@dkhcbc.edu.et",
        "password": "wrong_password",
    })
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_login_success(client: AsyncClient, admin_token: str):
    """admin_token fixture handles login; just verify the token is a non-empty string."""
    assert isinstance(admin_token, str)
    assert len(admin_token) > 20


@pytest.mark.asyncio
async def test_get_me_unauthenticated(client: AsyncClient):
    response = await client.get("/api/v1/auth/me")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_get_me_authenticated(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "testadmin@dkhcbc.edu.et"
    assert data["role"] == "admin"


@pytest.mark.asyncio
async def test_change_password(client: AsyncClient, admin_token: str):
    response = await client.post(
        "/api/v1/auth/change-password",
        json={"current_password": "TestPass@1234", "new_password": "NewPass@5678"},
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 204
