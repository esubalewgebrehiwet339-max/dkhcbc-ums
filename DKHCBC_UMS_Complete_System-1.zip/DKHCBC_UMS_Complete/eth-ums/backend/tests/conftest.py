"""Shared pytest fixtures for DKHCBC UMS test suite."""

import asyncio
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool

from shared.config.database import Base, get_db
from shared.models import orm_models  # noqa: F401 – register models
from main import app

# ── In-memory SQLite for tests ────────────────────────────────────────────────
TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

test_engine = create_async_engine(
    TEST_DB_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestSessionLocal = async_sessionmaker(
    bind=test_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def override_get_db():
    async with TestSessionLocal() as session:
        yield session


app.dependency_overrides[get_db] = override_get_db


@pytest_asyncio.fixture(scope="session", autouse=True)
async def create_test_tables():
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac


@pytest_asyncio.fixture
async def db_session():
    async with TestSessionLocal() as session:
        yield session


@pytest_asyncio.fixture
async def admin_token(client):
    """Create an admin user and return a valid JWT token."""
    from shared.models.orm_models import University, User, UserRole
    from services.auth.router import hash_password

    async with TestSessionLocal() as db:
        uni = University(code="TEST", name_en="Test University")
        db.add(uni)
        await db.flush()

        user = User(
            university_id=uni.id,
            email="testadmin@dkhcbc.edu.et",
            password_hash=hash_password("TestPass@1234"),
            role=UserRole.ADMIN,
            first_name_en="Test",
            last_name_en="Admin",
        )
        db.add(user)
        await db.commit()

    response = await client.post("/api/v1/auth/login", json={
        "email": "testadmin@dkhcbc.edu.et",
        "password": "TestPass@1234",
    })
    return response.json()["access_token"]
