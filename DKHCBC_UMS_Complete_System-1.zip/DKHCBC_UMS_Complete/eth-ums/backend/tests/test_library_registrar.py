"""Tests for Library and Registrar services."""

import pytest
from httpx import AsyncClient


# ── Library Tests ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_books_authenticated(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/library/books",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_list_books_unauthenticated(client: AsyncClient):
    response = await client.get("/api/v1/library/books")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_library_stats(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/library/stats",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "total_copies" in data
    assert "available" in data
    assert "active_loans" in data


# ── Registrar Tests ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_enrollment_queue_authenticated(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/registrar/enrollment-queue",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_registrar_student_list(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/registrar/students",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200


@pytest.mark.asyncio
async def test_transcript_data_not_found(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/registrar/students/NONEXISTENT/transcript-data",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 404


# ── Notification Tests ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_notifications(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/notifications",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_create_notification(client: AsyncClient, admin_token: str):
    response = await client.post(
        "/api/v1/notifications",
        json={
            "title": "Test Notification",
            "title_am": "የሙከራ ማሳወቂያ",
            "message": "This is a test broadcast notification.",
            "message_am": "ይህ የሙከራ ማሳወቂያ ነው።",
            "type": "info",
        },
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Test Notification"


# ── Admin Tests ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_audit_logs(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/admin/audit-logs",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_list_users(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/admin/users",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200


@pytest.mark.asyncio
async def test_student_router_search(client: AsyncClient, admin_token: str):
    response = await client.get(
        "/api/v1/students?q=abebe&limit=10",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200
